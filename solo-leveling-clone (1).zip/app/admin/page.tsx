"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Trash2 } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

type StoredUser = {
  id: string
  username: string
  email: string
  password: string
  level: number
  rank: string
  strength: number
  speed: number
  health: number
  defence: number
  dungeonsCleared: number
  shadowSoldiers: number
  guildPosition: string
  xp: number
  totalXp: number
  registeredAt?: string
  lastLogin?: string
}

type LoginRecord = {
  userId: string
  username: string
  email: string
  timestamp: string
  ipAddress?: string
  device?: string
}

export default function AdminPage() {
  const router = useRouter()
  const { user, isAuthenticated, getLoginHistory } = useAuth()
  const { toast } = useToast()
  const [users, setUsers] = useState<StoredUser[]>([])
  const [loginHistory, setLoginHistory] = useState<LoginRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<"users" | "logins">("users")

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
      return
    }

    // Only allow Ronish
    if (user?.username !== "Ronish") {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access the admin panel.",
        variant: "destructive",
      })
      router.push("/")
      return
    }

    try {
      const storedUsers = JSON.parse(localStorage.getItem("users") || "[]")
      setUsers(storedUsers)

      const history = getLoginHistory()
      setLoginHistory(history)
    } catch (error) {
      console.error("Failed to parse stored data:", error)
      toast({
        title: "Error",
        description: "Failed to load user data",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }, [isAuthenticated, user, router, toast, getLoginHistory])

  const deleteUser = (id: string) => {
    try {
      const updatedUsers = users.filter((u) => u.id !== id)
      localStorage.setItem("users", JSON.stringify(updatedUsers))
      setUsers(updatedUsers)
      toast({
        title: "Success",
        description: "User deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting user:", error)
      toast({
        title: "Error",
        description: "Failed to delete user",
        variant: "destructive",
      })
    }
  }

  const clearAllUsers = () => {
    try {
      localStorage.setItem("users", "[]")
      setUsers([])
      toast({
        title: "Success",
        description: "All users cleared successfully",
      })
    } catch (error) {
      console.error("Error clearing users:", error)
      toast({
        title: "Error",
        description: "Failed to clear users",
        variant: "destructive",
      })
    }
  }

  const clearLoginHistory = () => {
    try {
      localStorage.setItem("loginHistory", "[]")
      setLoginHistory([])
      toast({
        title: "Success",
        description: "Login history cleared successfully",
      })
    } catch (error) {
      console.error("Error clearing login history:", error)
      toast({
        title: "Error",
        description: "Failed to clear login history",
        variant: "destructive",
      })
    }
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A"
    try {
      return new Date(dateString).toLocaleString()
    } catch (e) {
      return dateString
    }
  }

  if (!user || user.username !== "Ronish") return null

  return (
    <div className="min-h-screen bg-[#0a1220] text-white">
      <div className="container mx-auto max-w-4xl py-8 px-4 pb-20">
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-cyan-400">Admin Dashboard</h1>
            {activeTab === "users" ? (
              <button
                onClick={clearAllUsers}
                className="px-4 py-2 bg-red-500/20 text-red-400 rounded-md hover:bg-red-500/30 transition-colors"
              >
                Clear All Users
              </button>
            ) : (
              <button
                onClick={clearLoginHistory}
                className="px-4 py-2 bg-red-500/20 text-red-400 rounded-md hover:bg-red-500/30 transition-colors"
              >
                Clear Login History
              </button>
            )}
          </div>

          {/* Tab Navigation */}
          <div className="flex border-b border-[#1a2a3a] mb-6">
            <button
              onClick={() => setActiveTab("users")}
              className={`px-4 py-2 ${
                activeTab === "users" ? "text-cyan-400 border-b-2 border-cyan-400" : "text-gray-400 hover:text-white"
              }`}
            >
              User Management
            </button>
            <button
              onClick={() => setActiveTab("logins")}
              className={`px-4 py-2 ${
                activeTab === "logins" ? "text-cyan-400 border-b-2 border-cyan-400" : "text-gray-400 hover:text-white"
              }`}
            >
              Login History
            </button>
          </div>

          {isLoading ? (
            <div className="text-center py-8">Loading data...</div>
          ) : activeTab === "users" ? (
            users.length === 0 ? (
              <div className="text-center py-8 text-gray-400">No registered users found</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#1a2a3a]">
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Username</th>
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Email</th>
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Password</th>
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Level</th>
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Registered</th>
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Last Login</th>
                      <th className="py-3 text-left text-sm font-medium text-gray-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((storedUser) => (
                      <tr key={storedUser.id} className="border-b border-[#1a2a3a]">
                        <td className="py-3 text-sm">{storedUser.username}</td>
                        <td className="py-3 text-sm">{storedUser.email}</td>
                        <td className="py-3 text-sm">{storedUser.password}</td>
                        <td className="py-3 text-sm">{storedUser.level}</td>
                        <td className="py-3 text-sm">{formatDate(storedUser.registeredAt)}</td>
                        <td className="py-3 text-sm">{formatDate(storedUser.lastLogin)}</td>
                        <td className="py-3 text-sm">
                          <button
                            onClick={() => deleteUser(storedUser.id)}
                            className="p-1 text-red-400 hover:text-red-300"
                            title="Delete User"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          ) : loginHistory.length === 0 ? (
            <div className="text-center py-8 text-gray-400">No login history found</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#1a2a3a]">
                    <th className="py-3 text-left text-sm font-medium text-gray-400">Username</th>
                    <th className="py-3 text-left text-sm font-medium text-gray-400">Email</th>
                    <th className="py-3 text-left text-sm font-medium text-gray-400">Login Time</th>
                    <th className="py-3 text-left text-sm font-medium text-gray-400">Device</th>
                  </tr>
                </thead>
                <tbody>
                  {loginHistory.map((record, index) => (
                    <tr key={index} className="border-b border-[#1a2a3a]">
                      <td className="py-3 text-sm">{record.username}</td>
                      <td className="py-3 text-sm">{record.email}</td>
                      <td className="py-3 text-sm">{formatDate(record.timestamp)}</td>
                      <td className="py-3 text-sm text-xs">
                        <div className="max-w-xs truncate">{record.device || "Unknown"}</div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6">
          <h2 className="text-lg font-bold text-cyan-400 mb-4">Local Storage Data</h2>
          <div className="bg-[#0a1220] p-4 rounded-lg overflow-x-auto">
            <pre className="text-xs text-gray-300 whitespace-pre-wrap">
              {JSON.stringify(
                {
                  users: users,
                  currentUser: user,
                  loginHistory: loginHistory,
                },
                null,
                2,
              )}
            </pre>
          </div>
        </div>
      </div>
    </div>
  )
}
