"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { LogOut, User, Shield, Award, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/hooks/use-auth"

export default function DashboardPage() {
  const router = useRouter()
  const { user, logout, isAuthenticated } = useAuth()

  // Protect this route
  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  if (!user) {
    return null // Don't render anything while checking authentication
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-700 to-slate-900 text-white">
      <header className="border-b border-slate-700">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="text-xl font-bold">
            Quest Master
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-300">Welcome, {user.username}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className="text-slate-300 hover:text-white hover:bg-slate-700"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Adventurer Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Level</CardTitle>
              <CardDescription className="text-slate-400">Current progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">5</div>
              <div className="mt-2 h-2 bg-slate-700 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 w-[45%]"></div>
              </div>
              <div className="mt-1 text-xs text-slate-400">45% to level 6</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Rank</CardTitle>
              <CardDescription className="text-slate-400">Adventurer status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-500">E</div>
              <div className="mt-2 text-sm text-slate-400">E-Rank Adventurer</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Quests</CardTitle>
              <CardDescription className="text-slate-400">Completed missions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">7</div>
              <div className="mt-2 text-sm text-slate-400">2 quests available</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">HP</CardTitle>
              <CardDescription className="text-slate-400">Health points</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">120/120</div>
              <div className="mt-2 h-2 bg-slate-700 rounded-full overflow-hidden">
                <div className="h-full bg-green-500 w-full"></div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Available Quests</CardTitle>
                <CardDescription className="text-slate-400">Select your next mission</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { title: "Defeat the Forest Guardian", level: "E", reward: "50 XP, 100 Gold" },
                    { title: "Explore the Ancient Ruins", level: "E", reward: "75 XP, 150 Gold" },
                  ].map((quest, index) => (
                    <div
                      key={index}
                      className="p-4 border border-slate-700 rounded-lg hover:bg-slate-700/50 transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{quest.title}</h3>
                          <p className="text-sm text-slate-400">Reward: {quest.reward}</p>
                        </div>
                        <span className="px-2 py-1 text-xs rounded bg-yellow-500/20 text-yellow-400">
                          {quest.level}-Rank
                        </span>
                      </div>
                      <div className="mt-4">
                        <Button size="sm" className="bg-slate-700 hover:bg-slate-600">
                          Start Quest
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Adventurer Menu</CardTitle>
                <CardDescription className="text-slate-400">Quick access</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-700"
                  >
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-700"
                  >
                    <Shield className="mr-2 h-4 w-4" />
                    Inventory
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-700"
                  >
                    <Award className="mr-2 h-4 w-4" />
                    Skills
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-700"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
