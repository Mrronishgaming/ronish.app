"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

export default function LoginPage() {
  const router = useRouter()
  const { login } = useAuth()
  const { toast } = useToast()
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [loginStatus, setLoginStatus] = useState<"idle" | "success" | "error">("idle")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setLoginStatus("idle")

    // Simple validation
    if (!formData.email || !formData.password) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    try {
      // Attempt login
      const success = login(formData.email, formData.password)

      if (success) {
        setLoginStatus("success")
        toast({
          title: "Success",
          description: "You have successfully logged in",
        })
        router.push("/")
      } else {
        setLoginStatus("error")
        toast({
          title: "Error",
          description: "Invalid email or password",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Login error:", error)
      setLoginStatus("error")
      toast({
        title: "Error",
        description: "An unexpected error occurred during login",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a1220] text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-cyan-400">Solo Leveling</h1>
          <p className="text-gray-400 mt-2">Sign in to continue your journey</p>
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-[#0a1220] border border-[#1a2a3a] rounded-md text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-[#0a1220] border border-[#1a2a3a] rounded-md text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 pr-10"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-2 rounded-md font-medium transition-colors disabled:opacity-50"
            >
              {isLoading ? "Signing in..." : "Sign In"}
            </button>
          </form>

          <div className="mt-4 text-center text-sm text-gray-400">
            <p>
              Don&apos;t have an account?{" "}
              <Link href="/register" className="text-cyan-400 hover:underline">
                Register
              </Link>
            </p>
            <p className="mt-2 text-xs">For demo: email: guest@example.com, password: password</p>
          </div>

          {loginStatus === "success" && (
            <div className="mt-4 p-3 bg-green-500/20 text-green-400 rounded-md text-sm">
              Login successful! Redirecting to home page...
            </div>
          )}

          {loginStatus === "error" && (
            <div className="mt-4 p-3 bg-red-500/20 text-red-400 rounded-md text-sm">
              Login failed. Please check your credentials and try again.
            </div>
          )}
        </div>

        <div className="mt-4 text-center">
          <Link href="/login" className="text-xs text-gray-500 hover:text-cyan-400">
          Lock ON
          </Link>
        </div>
      </div>
    </div>
  )
}
