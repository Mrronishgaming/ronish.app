"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useAuth } from "@/hooks/use-auth"

export default function HomePage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  if (!user) return null

  // Calculate XP needed for next level based on current level
  const calculateXpForNextLevel = (level: number): number => {
    return level * 10
  }

  const xpForNextLevel = calculateXpForNextLevel(user.level)

  // Calculate XP progress percentage
  const xpProgressPercentage = (user.xp / xpForNextLevel) * 100

  return (
    <div className="min-h-screen bg-[#0a1220] text-white">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full border-2 border-cyan-500 flex items-center justify-center bg-[#0a1220] overflow-hidden relative">
              {user.profilePicture ? (
                <Image
                  src={user.profilePicture || "/placeholder.svg"}
                  alt={user.username}
                  fill
                  className="object-cover"
                />
              ) : (
                <span className="text-xl">{user.username.charAt(0)}</span>
              )}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-cyan-400">Welcome, {user.username}!</h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-sm text-gray-300">Level {user.level}</span>
                <span className="bg-cyan-500/20 text-cyan-400 px-2 py-0.5 rounded-full text-xs">{user.rank}-Rank</span>
              </div>
            </div>
          </div>

          {/* Add XP progress bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-1">
              <span>Experience</span>
              <span>
                {user.xp} / {xpForNextLevel} XP
              </span>
            </div>
            <div className="h-2 bg-[#0a1220] rounded-full overflow-hidden">
              <div className="h-full bg-cyan-500" style={{ width: `${xpProgressPercentage}%` }}></div>
            </div>
            <div className="flex justify-between text-xs mt-1">
              <span>Total XP: {user.totalXp}</span>
              <span>Next Level: {user.level + 1}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <Link href="/profile" className="bg-[#0a1220] hover:bg-[#111e2e] rounded-lg p-4 transition-colors">
              <h2 className="text-lg font-medium text-cyan-400 mb-2">View Profile</h2>
              <p className="text-sm text-gray-400">Check your stats and abilities</p>
            </Link>

            <Link href="/rank" className="bg-[#0a1220] hover:bg-[#111e2e] rounded-lg p-4 transition-colors">
              <h2 className="text-lg font-medium text-cyan-400 mb-2">Leaderboard</h2>
              <p className="text-sm text-gray-400">See how you rank against others</p>
            </Link>

            <Link href="/workout" className="bg-[#0a1220] hover:bg-[#111e2e] rounded-lg p-4 transition-colors">
              <h2 className="text-lg font-medium text-cyan-400 mb-2">Start Workout</h2>
              <p className="text-sm text-gray-400">Train to increase your stats</p>
            </Link>
          </div>
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6">
          <h2 className="text-lg font-bold text-cyan-400 mb-4">Rank System</h2>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <div className={`p-3 rounded-lg ${user.rank === "F" ? "bg-cyan-500/20" : "bg-[#0a1220]"}`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "F" ? "text-cyan-400" : "text-gray-400"}`}>
                  F-Rank
                </div>
                <div className="text-xs text-gray-400">10-100 XP</div>
              </div>
            </div>

            <div className={`p-3 rounded-lg ${user.rank === "E" ? "bg-cyan-500/20" : "bg-[#0a1220]"}`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "E" ? "text-cyan-400" : "text-gray-400"}`}>
                  E-Rank
                </div>
                <div className="text-xs text-gray-400">100-200 XP</div>
              </div>
            </div>

            <div className={`p-3 rounded-lg ${user.rank === "D" ? "bg-cyan-500/20" : "bg-[#0a1220]"}`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "D" ? "text-cyan-400" : "text-gray-400"}`}>
                  D-Rank
                </div>
                <div className="text-xs text-gray-400">200-300 XP</div>
              </div>
            </div>

            <div className={`p-3 rounded-lg ${user.rank === "C" ? "bg-cyan-500/20" : "bg-[#0a1220]"}`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "C" ? "text-cyan-400" : "text-gray-400"}`}>
                  C-Rank
                </div>
                <div className="text-xs text-gray-400">300-400 XP</div>
              </div>
            </div>

            <div className={`p-3 rounded-lg ${user.rank === "A" ? "bg-cyan-500/20" : "bg-[#0a1220]"}`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "A" ? "text-cyan-400" : "text-gray-400"}`}>
                  A-Rank
                </div>
                <div className="text-xs text-gray-400">400-500 XP</div>
              </div>
            </div>

            <div className={`p-3 rounded-lg ${user.rank === "S" ? "bg-cyan-500/20" : "bg-[#0a1220]"}`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "S" ? "text-cyan-400" : "text-gray-400"}`}>
                  S-Rank
                </div>
                <div className="text-xs text-gray-400">500-900 XP</div>
              </div>
            </div>

            <div className={`p-3 rounded-lg ${user.rank === "S+" ? "bg-cyan-500/20" : "bg-[#0a1220]"} md:col-span-3`}>
              <div className="text-center">
                <div className={`text-lg font-bold ${user.rank === "S+" ? "text-cyan-400" : "text-gray-400"}`}>
                  S+-Rank
                </div>
                <div className="text-xs text-gray-400">1000+ XP</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
