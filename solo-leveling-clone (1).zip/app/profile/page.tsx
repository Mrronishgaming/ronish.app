"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Award, TrendingUp, User, Calendar, MapPin, Upload, X, Check, ChevronDown } from "lucide-react"
import Image from "next/image"

// List of countries
const countries = [
  "Afghanistan",
  "Albania",
  "Algeria",
  "Andorra",
  "Angola",
  "Antigua and Barbuda",
  "Argentina",
  "Armenia",
  "Australia",
  "Austria",
  "Azerbaijan",
  "Bahamas",
  "Bahrain",
  "Bangladesh",
  "Barbados",
  "Belarus",
  "Belgium",
  "Belize",
  "Benin",
  "Bhutan",
  "Bolivia",
  "Bosnia and Herzegovina",
  "Botswana",
  "Brazil",
  "Brunei",
  "Bulgaria",
  "Burkina Faso",
  "Burundi",
  "Cabo Verde",
  "Cambodia",
  "Cameroon",
  "Canada",
  "Central African Republic",
  "Chad",
  "Chile",
  "China",
  "Colombia",
  "Comoros",
  "Congo",
  "Costa Rica",
  "Croatia",
  "Cuba",
  "Cyprus",
  "Czech Republic",
  "Denmark",
  "Djibouti",
  "Dominica",
  "Dominican Republic",
  "Ecuador",
  "Egypt",
  "El Salvador",
  "Equatorial Guinea",
  "Eritrea",
  "Estonia",
  "Eswatini",
  "Ethiopia",
  "Fiji",
  "Finland",
  "France",
  "Gabon",
  "Gambia",
  "Georgia",
  "Germany",
  "Ghana",
  "Greece",
  "Grenada",
  "Guatemala",
  "Guinea",
  "Guinea-Bissau",
  "Guyana",
  "Haiti",
  "Honduras",
  "Hungary",
  "Iceland",
  "India",
  "Indonesia",
  "Iran",
  "Iraq",
  "Ireland",
  "Israel",
  "Italy",
  "Jamaica",
  "Japan",
  "Jordan",
  "Kazakhstan",
  "Kenya",
  "Kiribati",
  "Korea, North",
  "Korea, South",
  "Kosovo",
  "Kuwait",
  "Kyrgyzstan",
  "Laos",
  "Latvia",
  "Lebanon",
  "Lesotho",
  "Liberia",
  "Libya",
  "Liechtenstein",
  "Lithuania",
  "Luxembourg",
  "Madagascar",
  "Malawi",
  "Malaysia",
  "Maldives",
  "Mali",
  "Malta",
  "Marshall Islands",
  "Mauritania",
  "Mauritius",
  "Mexico",
  "Micronesia",
  "Moldova",
  "Monaco",
  "Mongolia",
  "Montenegro",
  "Morocco",
  "Mozambique",
  "Myanmar",
  "Namibia",
  "Nauru",
  "Nepal",
  "Netherlands",
  "New Zealand",
  "Nicaragua",
  "Niger",
  "Nigeria",
  "North Macedonia",
  "Norway",
  "Oman",
  "Pakistan",
  "Palau",
  "Palestine",
  "Panama",
  "Papua New Guinea",
  "Paraguay",
  "Peru",
  "Philippines",
  "Poland",
  "Portugal",
  "Qatar",
  "Romania",
  "Russia",
  "Rwanda",
  "Saint Kitts and Nevis",
  "Saint Lucia",
  "Saint Vincent and the Grenadines",
  "Samoa",
  "San Marino",
  "Sao Tome and Principe",
  "Saudi Arabia",
  "Senegal",
  "Serbia",
  "Seychelles",
  "Sierra Leone",
  "Singapore",
  "Slovakia",
  "Slovenia",
  "Solomon Islands",
  "Somalia",
  "South Africa",
  "South Sudan",
  "Spain",
  "Sri Lanka",
  "Sudan",
  "Suriname",
  "Sweden",
  "Switzerland",
  "Syria",
  "Taiwan",
  "Tajikistan",
  "Tanzania",
  "Thailand",
  "Timor-Leste",
  "Togo",
  "Tonga",
  "Trinidad and Tobago",
  "Tunisia",
  "Turkey",
  "Turkmenistan",
  "Tuvalu",
  "Uganda",
  "Ukraine",
  "United Arab Emirates",
  "United Kingdom",
  "United States",
  "Uruguay",
  "Uzbekistan",
  "Vanuatu",
  "Vatican City",
  "Venezuela",
  "Vietnam",
  "Yemen",
  "Zambia",
  "Zimbabwe",
]

export default function ProfilePage() {
  const router = useRouter()
  const { user, isAuthenticated, updateUserProfile, unlockAchievement } = useAuth()
  const [editingCountry, setEditingCountry] = useState(false)
  const [selectedCountry, setSelectedCountry] = useState("")
  const [countrySearch, setCountrySearch] = useState("")
  const [showCountryDropdown, setShowCountryDropdown] = useState(false)
  const [uploadingImage, setUploadingImage] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const countryDropdownRef = useRef<HTMLDivElement>(null)
  const [completedAchievements, setCompletedAchievements] = useState<number>(0)
  const [totalAchievements, setTotalAchievements] = useState<number>(0)
  const [userRanking, setUserRanking] = useState<number | null>(null)
  const [setSelect, setSetSelect] = useState("")

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  useEffect(() => {
    if (user) {
      setSetSelect(user.country || "")

      // Count achievements
      const completed = user.achievements.filter((a) => a.completed).length
      const total = user.achievements.length
      setCompletedAchievements(completed)
      setTotalAchievements(total)

      // Calculate user ranking
      try {
        const allUsers = JSON.parse(localStorage.getItem("users") || "[]")
        // Sort users by total XP
        const sortedUsers = allUsers.sort((a: any, b: any) => b.totalXp - a.totalXp)
        // Find user's position
        const userPosition = sortedUsers.findIndex((u: any) => u.id === user.id)
        if (userPosition !== -1) {
          setUserRanking(userPosition + 1)
        }
      } catch (error) {
        console.error("Failed to calculate ranking:", error)
      }
    }
  }, [user])

  // Handle clicks outside the country dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (countryDropdownRef.current && !countryDropdownRef.current.contains(event.target as Node)) {
        setShowCountryDropdown(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  if (!user) return null

  // Calculate XP needed for next level based on current level
  const calculateXpForNextLevel = (level: number): number => {
    return level * 10
  }

  const xpForNextLevel = calculateXpForNextLevel(user.level)

  // Calculate XP progress percentage
  const xpProgressPercentage = (user.xp / xpForNextLevel) * 100

  // Format date for display
  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A"
    try {
      return new Date(dateString).toLocaleString()
    } catch (e) {
      return dateString
    }
  }

  // Filter countries based on search
  const filteredCountries = countries.filter((country) => country.toLowerCase().includes(countrySearch.toLowerCase()))

  // Handle country selection
  const handleCountrySelect = (country: string) => {
    setSelectedCountry(country)
    setShowCountryDropdown(false)
  }

  // Save country selection
  const saveCountrySelection = () => {
    if (selectedCountry) {
      updateUserProfile({ country: selectedCountry })
      setEditingCountry(false)
    }
  }

  // Handle profile picture upload
  const handleProfilePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingImage(true)

    // In a real app, you would upload the file to a server
    // For this demo, we'll use FileReader to convert the image to a data URL
    const reader = new FileReader()
    reader.onload = (event) => {
      const imageDataUrl = event.target?.result as string
      updateUserProfile({ profilePicture: imageDataUrl })
      setUploadingImage(false)
    }
    reader.onerror = () => {
      setUploadingImage(false)
      alert("Error uploading image. Please try again.")
    }
    reader.readAsDataURL(file)
  }

  // Group achievements by type
  const achievementsByType = user.achievements.reduce(
    (acc, achievement) => {
      if (!acc[achievement.type]) {
        acc[achievement.type] = []
      }
      acc[achievement.type].push(achievement)
      return acc
    },
    {} as Record<string, typeof user.achievements>,
  )

  return (
    <div className="min-h-screen bg-[#0a1220] text-white">
      <main className="container mx-auto max-w-4xl py-8 px-4">
        {/* Profile Header */}
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="relative">
              <div className="w-24 h-24 md:w-28 md:h-28 rounded-full border-2 border-cyan-500 flex items-center justify-center bg-[#0a1220] overflow-hidden relative">
                {user.profilePicture ? (
                  <Image
                    src={user.profilePicture || "/placeholder.svg"}
                    alt={user.username}
                    fill
                    className="object-cover"
                  />
                ) : (
                  <span className="text-3xl">{user.username.charAt(0)}</span>
                )}

                {/* Upload button */}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute bottom-0 right-0 bg-cyan-500 rounded-full p-1 shadow-lg hover:bg-cyan-600 transition-colors"
                  disabled={uploadingImage}
                >
                  {uploadingImage ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <Upload className="w-4 h-4 text-white" />
                  )}
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleProfilePictureUpload}
                />
              </div>
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-[#0a1220] border border-cyan-500 rounded-full px-2 py-0.5 text-xs">
                <div className="text-center">
                  <div className="text-xs text-cyan-500">LVL</div>
                  <div>{user.level}</div>
                </div>
              </div>
            </div>

            <div className="flex-1 text-center md:text-left">
              <h1 className="text-2xl font-bold text-cyan-400">{user.username}</h1>
              <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4 text-sm text-gray-300 mt-1">
                <span>The Fitness</span>
                <span className="text-cyan-400">Fitness Association</span>
              </div>
              <div className="mt-2 flex flex-wrap justify-center md:justify-start gap-2">
                <span className="bg-cyan-500/20 text-cyan-400 px-3 py-1 rounded-full text-xs flex items-center">
                  <Award className="w-3 h-3 mr-1" />
                  {user.rank}-Rank
                </span>

                {/* Country selection */}
                <div className="relative">
                  {editingCountry ? (
                    <div className="flex items-center gap-1">
                      <div className="relative" ref={countryDropdownRef}>
                        <div
                          className="bg-[#0a1220] border border-[#1a2a3a] rounded-md px-3 py-1 text-xs flex items-center cursor-pointer"
                          onClick={() => setShowCountryDropdown(!showCountryDropdown)}
                        >
                          <MapPin className="w-3 h-3 mr-1 text-cyan-400" />
                          {selectedCountry || "Select Country"}
                          <ChevronDown className="w-3 h-3 ml-1" />
                        </div>

                        {showCountryDropdown && (
                          <div className="absolute z-10 mt-1 w-56 max-h-60 overflow-y-auto bg-[#0a1220] border border-[#1a2a3a] rounded-md shadow-lg">
                            <div className="p-2 sticky top-0 bg-[#0a1220] border-b border-[#1a2a3a]">
                              <input
                                type="text"
                                value={countrySearch}
                                onChange={(e) => setCountrySearch(e.target.value)}
                                placeholder="Search countries..."
                                className="w-full px-2 py-1 bg-[#0f1c2e] border border-[#1a2a3a] rounded text-xs focus:outline-none focus:border-cyan-500"
                              />
                            </div>
                            <div>
                              {filteredCountries.map((country) => (
                                <div
                                  key={country}
                                  className={`px-3 py-2 text-xs cursor-pointer hover:bg-[#1a2a3a] ${
                                    selectedCountry === country ? "bg-cyan-500/20 text-cyan-400" : ""
                                  }`}
                                  onClick={() => handleCountrySelect(country)}
                                >
                                  {country}
                                </div>
                              ))}
                              {filteredCountries.length === 0 && (
                                <div className="px-3 py-2 text-xs text-gray-400">No countries found</div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                      <button
                        onClick={saveCountrySelection}
                        className="bg-cyan-500/20 text-cyan-400 rounded-full p-1 hover:bg-cyan-500/30"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => {
                          setEditingCountry(false)
                          setSelectedCountry(user.country || "")
                        }}
                        className="bg-red-500/20 text-red-400 rounded-full p-1 hover:bg-red-500/30"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <span
                      className="bg-[#0a1220] border border-[#1a2a3a] rounded-md px-3 py-1 text-xs flex items-center cursor-pointer hover:border-cyan-500/30"
                      onClick={() => setEditingCountry(true)}
                    >
                      <MapPin className="w-3 h-3 mr-1 text-cyan-400" />
                      {user.country === "Select" ? "Select Country" : user.country}
                    </span>
                  )}
                </div>
              </div>

              {/* Account Info */}
              <div className="mt-3 text-xs text-gray-400">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  <span>Member since: {formatDate(user.registeredAt)}</span>
                </div>
                <div>Last login: {formatDate(user.lastLogin)}</div>
              </div>

              {/* Add XP progress bar */}
              <div className="mt-4">
                <div className="flex justify-between text-xs mb-1">
                  <span>XP Progress</span>
                  <span>
                    {user.xp} / {xpForNextLevel}
                  </span>
                </div>
                <div className="h-1.5 bg-[#0a1220] rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500" style={{ width: `${xpProgressPercentage}%` }}></div>
                </div>
                <div className="flex justify-between text-xs mt-1">
                  <span>Total XP: {user.totalXp}</span>
                  <span>Next Level: {user.level + 1}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats and Status */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Fitness Statistics */}
          <div className="bg-[#0f1c2e] rounded-lg p-6">
            <h2 className="text-lg font-bold text-cyan-400 mb-4">FITNESS STATISTICS</h2>

            <div className="space-y-4">
              <div>
                <div className="flex items-center mb-1">
                  <svg
                    className="w-4 h-4 mr-2 text-cyan-400"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                  </svg>
                  <span className="text-sm">STRENGTH</span>
                  <span className="ml-auto">{user.strength}</span>
                </div>
                <div className="h-1 bg-[#0a1220] rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500" style={{ width: `${user.strength * 5}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex items-center mb-1">
                  <svg
                    className="w-4 h-4 mr-2 text-cyan-400"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M13 5L21 12L13 19V5Z" fill="currentColor" />
                    <path d="M3 5L11 12L3 19V5Z" fill="currentColor" />
                  </svg>
                  <span className="text-sm">SPEED</span>
                  <span className="ml-auto">{user.speed}</span>
                </div>
                <div className="h-1 bg-[#0a1220] rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500" style={{ width: `${user.speed * 5}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex items-center mb-1">
                  <svg
                    className="w-4 h-4 mr-2 text-cyan-400"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                  </svg>
                  <span className="text-sm">HEALTH</span>
                  <span className="ml-auto">{user.health}</span>
                </div>
                <div className="h-1 bg-[#0a1220] rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500" style={{ width: `${user.health * 5}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex items-center mb-1">
                  <svg
                    className="w-4 h-4 mr-2 text-cyan-400"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                  </svg>
                  <span className="text-sm">DEFENCE</span>
                  <span className="ml-auto">{user.defence}</span>
                </div>
                <div className="h-1 bg-[#0a1220] rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500" style={{ width: `${user.defence * 5}%` }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="bg-[#0f1c2e] rounded-lg p-6">
            <h2 className="text-lg font-bold text-cyan-400 mb-4">STATUS</h2>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Rank</span>
                <span className="text-cyan-400">{user.rank}-Rank</span>
              </div>

              <div className="flex justify-between">
                <span className="text-sm">Level</span>
                <span className="text-cyan-400">{user.level}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-sm">Total EXP</span>
                <span className="text-cyan-400">{user.totalXp}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-sm">Total Workouts</span>
                <span className="text-cyan-400">{user.workoutsCompleted || 0}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-sm">Ranking</span>
                <span className="text-cyan-400">{userRanking ? `#${userRanking}` : "-"}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Rank Information */}
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <h2 className="text-lg font-bold text-cyan-400 mb-4">RANK SYSTEM</h2>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1a2a3a]">
                  <th className="py-2 text-left text-sm font-medium text-gray-400">Rank</th>
                  <th className="py-2 text-left text-sm font-medium text-gray-400">Required XP</th>
                  <th className="py-2 text-left text-sm font-medium text-gray-400">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr className={`border-b border-[#1a2a3a] ${user.rank === "F" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">F-Rank</td>
                  <td className="py-2 text-sm">10-100</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 10 && user.totalXp < 100 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : user.totalXp >= 100 ? (
                      <span className="text-green-400">Achieved</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
                <tr className={`border-b border-[#1a2a3a] ${user.rank === "E" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">E-Rank</td>
                  <td className="py-2 text-sm">100-200</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 100 && user.totalXp < 200 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : user.totalXp >= 200 ? (
                      <span className="text-green-400">Achieved</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
                <tr className={`border-b border-[#1a2a3a] ${user.rank === "D" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">D-Rank</td>
                  <td className="py-2 text-sm">200-300</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 200 && user.totalXp < 300 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : user.totalXp >= 300 ? (
                      <span className="text-green-400">Achieved</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
                <tr className={`border-b border-[#1a2a3a] ${user.rank === "C" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">C-Rank</td>
                  <td className="py-2 text-sm">300-400</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 300 && user.totalXp < 400 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : user.totalXp >= 400 ? (
                      <span className="text-green-400">Achieved</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
                <tr className={`border-b border-[#1a2a3a] ${user.rank === "A" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">A-Rank</td>
                  <td className="py-2 text-sm">400-500</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 400 && user.totalXp < 500 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : user.totalXp >= 500 ? (
                      <span className="text-green-400">Achieved</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
                <tr className={`border-b border-[#1a2a3a] ${user.rank === "S" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">S-Rank</td>
                  <td className="py-2 text-sm">500-900</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 500 && user.totalXp < 900 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : user.totalXp >= 900 ? (
                      <span className="text-green-400">Achieved</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
                <tr className={`${user.rank === "S+" ? "bg-cyan-500/10" : ""}`}>
                  <td className="py-2 text-sm">S+-Rank</td>
                  <td className="py-2 text-sm">1000+</td>
                  <td className="py-2 text-sm">
                    {user.totalXp >= 1000 ? (
                      <span className="text-cyan-400">Current</span>
                    ) : (
                      <span className="text-gray-500">Locked</span>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold text-cyan-400">ACHIEVEMENTS</h2>
            <span className="text-sm text-gray-300">
              {completedAchievements}/{totalAchievements} (
              {Math.round((completedAchievements / totalAchievements) * 100)}%)
            </span>
          </div>

          {/* Join Achievements */}
          {achievementsByType.join && (
            <div className="mb-4">
              <h3 className="text-sm font-medium text-cyan-400 mb-2 border-b border-[#1a2a3a] pb-1">Account</h3>
              <div className="space-y-3">
                {achievementsByType.join.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`bg-[#0a1220] rounded-lg p-4 ${achievement.completed ? "border border-green-500/30" : "opacity-60"}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mt-1">
                        <User className="w-5 h-5" />
                      </div>

                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{achievement.title}</h3>
                        <p className="text-xs text-gray-300 mb-2">{achievement.description}</p>

                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{achievement.completed ? "Completed" : "Incomplete"}</span>
                          {achievement.completed && <span>Completed: {formatDate(achievement.date)}</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Workout Achievements */}
          {achievementsByType.first_workout && (
            <div className="mb-4">
              <h3 className="text-sm font-medium text-cyan-400 mb-2 border-b border-[#1a2a3a] pb-1">Workouts</h3>
              <div className="space-y-3">
                {achievementsByType.first_workout.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`bg-[#0a1220] rounded-lg p-4 ${achievement.completed ? "border border-green-500/30" : "opacity-60"}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mt-1">
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          <path d="M6 18L18 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                        </svg>
                      </div>

                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{achievement.title}</h3>
                        <p className="text-xs text-gray-300 mb-2">{achievement.description}</p>

                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{achievement.completed ? "Completed" : "Incomplete"}</span>
                          {achievement.completed && <span>Completed: {formatDate(achievement.date)}</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Level Up Achievements */}
          {achievementsByType.level_up && (
            <div className="mb-4">
              <h3 className="text-sm font-medium text-cyan-400 mb-2 border-b border-[#1a2a3a] pb-1">
                Level Milestones
              </h3>
              <div className="space-y-3">
                {achievementsByType.level_up.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`bg-[#0a1220] rounded-lg p-4 ${achievement.completed ? "border border-green-500/30" : "opacity-60"}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mt-1">
                        <TrendingUp className="w-5 h-5" />
                      </div>

                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{achievement.title}</h3>
                        <p className="text-xs text-gray-300 mb-2">{achievement.description}</p>

                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{achievement.completed ? "Completed" : "Incomplete"}</span>
                          {achievement.completed && <span>Completed: {formatDate(achievement.date)}</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Rank Achievements */}
          {achievementsByType.rank_up && (
            <div>
              <h3 className="text-sm font-medium text-cyan-400 mb-2 border-b border-[#1a2a3a] pb-1">Rank Milestones</h3>
              <div className="space-y-3">
                {achievementsByType.rank_up.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`bg-[#0a1220] rounded-lg p-4 ${achievement.completed ? "border border-green-500/30" : "opacity-60"}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mt-1">
                        <Award className="w-5 h-5" />
                      </div>

                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{achievement.title}</h3>
                        <p className="text-xs text-gray-300 mb-2">{achievement.description}</p>

                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{achievement.completed ? "Completed" : "Incomplete"}</span>
                          {achievement.completed && <span>Completed: {formatDate(achievement.date)}</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* First Rank Achievement */}
          {achievementsByType.first_rank && (
            <div>
              <h3 className="text-sm font-medium text-cyan-400 mb-2 border-b border-[#1a2a3a] pb-1">First Rank</h3>
              <div className="space-y-3">
                {achievementsByType.first_rank.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`bg-[#0a1220] rounded-lg p-4 ${achievement.completed ? "border border-green-500/30" : "opacity-60"}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mt-1">
                        <Award className="w-5 h-5" />
                      </div>

                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{achievement.title}</h3>
                        <p className="text-xs text-gray-300 mb-2">{achievement.description}</p>

                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{achievement.completed ? "Completed" : "Incomplete"}</span>
                          {achievement.completed && <span>Completed: {formatDate(achievement.date)}</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Skills & Abilities */}
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <h2 className="text-lg font-bold text-cyan-400 mb-4">SKILLS & ABILITIES</h2>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Skill 1 */}
            <div className="bg-[#0a1220] rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400">
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 5L21 12L13 19V5Z" fill="currentColor" />
                    <path d="M3 5L11 12L3 19V5Z" fill="currentColor" />
                  </svg>
                </div>
                <div>
                  <div className="text-sm font-medium">Dominator's Touch</div>
                  <div className="text-xs text-gray-400">Lv.3/5</div>
                </div>
              </div>

              <div className="text-xs text-gray-300 mb-2">
                Deal physical damage and steal target's strength temporarily.
              </div>

              <div className="text-xs text-gray-400">Cooldown: 30s</div>
            </div>

            {/* Skill 2 */}
            <div className="bg-[#0a1220] rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400">
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                  </svg>
                </div>
                <div>
                  <div className="text-sm font-medium">Shadow Exchange</div>
                  <div className="text-xs text-gray-400">Lv.2/3</div>
                </div>
              </div>

              <div className="text-xs text-gray-300 mb-2">Swap positions with your shadow, leaving a decoy behind.</div>

              <div className="text-xs text-gray-400">Cooldown: 45s</div>
            </div>

            {/* Skill 3 */}
            <div className="bg-[#0a1220] rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400">
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                      fill="currentColor"
                    />
                  </svg>
                </div>
                <div>
                  <div className="text-sm font-medium">Monarch's Domain</div>
                  <div className="text-xs text-gray-400">Lv.1/5</div>
                </div>
              </div>

              <div className="text-xs text-gray-300 mb-2">
                Create a field where you gain increased abilities and enemies are weakened.
              </div>

              <div className="text-xs text-gray-400">Cooldown: 3m</div>
            </div>

            {/* Skill 4 */}
            <div className="bg-[#0a1220] rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400">
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                      fill="currentColor"
                    />
                  </svg>
                </div>
                <div>
                  <div className="text-sm font-medium">Arise</div>
                  <div className="text-xs text-gray-400">Lv.5/5</div>
                </div>
              </div>

              <div className="text-xs text-gray-300 mb-2">
                Extract a shadow from fallen enemies to serve you in battle.
              </div>

              <div className="text-xs text-gray-400">Cooldown: 5m</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
