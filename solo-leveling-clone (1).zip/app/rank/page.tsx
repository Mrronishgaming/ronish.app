"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import Image from "next/image"

type RankUser = {
  id: string
  username: string
  level: number
  rank: string
  totalXp: number
  country: string
  profilePicture?: string
  position?: number
}

export default function RankPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const [rankings, setRankings] = useState<RankUser[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
      return
    }

    // Get all users from localStorage
    try {
      const allUsers = JSON.parse(localStorage.getItem("users") || "[]")

      // Sort users by total XP
      const sortedUsers = allUsers
        .sort((a: any, b: any) => b.totalXp - a.totalXp)
        .map((u: any, index: number) => ({
          id: u.id,
          username: u.username,
          level: u.level || 1,
          rank: u.rank || "Unranked",
          totalXp: u.totalXp || 0,
          country: u.country || "Unknown",
          profilePicture: u.profilePicture,
          position: index + 1,
        }))
        .slice(0, 10) // Only show top 10

      // Create a fixed-size array of 10 elements
      const fixedRankings: RankUser[] = Array(10)
        .fill(null)
        .map((_, index) => {
          if (index < sortedUsers.length) {
            return sortedUsers[index]
          }
          // Return empty placeholder for remaining slots
          return {
            id: `empty-${index}`,
            username: "",
            level: 0,
            rank: "",
            totalXp: 0,
            country: "",
            position: index + 1,
          }
        })

      setRankings(fixedRankings)
    } catch (error) {
      console.error("Failed to load users:", error)
      // Create empty rankings if there's an error
      const emptyRankings = Array(10)
        .fill(null)
        .map((_, index) => ({
          id: `empty-${index}`,
          username: "",
          level: 0,
          rank: "",
          totalXp: 0,
          country: "",
          position: index + 1,
        }))
      setRankings(emptyRankings)
    }

    setLoading(false)
  }, [isAuthenticated, router, user])

  if (!user || loading) {
    return (
      <div className="min-h-screen bg-[#0a1220] text-white flex items-center justify-center">
        <div className="text-cyan-400">Loading rankings...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a1220] text-white">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <h1 className="text-2xl font-bold text-cyan-400 mb-4">Rankings</h1>
          <p className="text-gray-300 mb-4">See how you compare to others based on total experience.</p>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-[#0a1220]">
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-400 border border-[#1a2a3a]">Top</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-400 border border-[#1a2a3a]">
                    Name
                  </th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-400 border border-[#1a2a3a]">
                    Level
                  </th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-400 border border-[#1a2a3a]">
                    Rank
                  </th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-400 border border-[#1a2a3a]">
                    Experience
                  </th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-400 border border-[#1a2a3a]">
                    Country
                  </th>
                </tr>
              </thead>
              <tbody>
                {rankings.map((rankedUser) => (
                  <tr
                    key={rankedUser.id}
                    className={`border border-[#1a2a3a] ${rankedUser.id === user.id ? "bg-cyan-500/10" : ""}`}
                  >
                    <td className="py-3 px-4 border border-[#1a2a3a]">{rankedUser.position}</td>
                    <td className="py-3 px-4 border border-[#1a2a3a]">
                      {rankedUser.username !== "" && (
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-[#0a1220] border border-[#1a2a3a] flex items-center justify-center mr-2 overflow-hidden">
                            {rankedUser.profilePicture ? (
                              <Image
                                src={rankedUser.profilePicture || "/placeholder.svg"}
                                alt={rankedUser.username}
                                width={32}
                                height={32}
                                className="object-cover"
                              />
                            ) : (
                              rankedUser.username && <span>{rankedUser.username.charAt(0)}</span>
                            )}
                          </div>
                          <span className={rankedUser.id === user.id ? "font-medium text-cyan-400" : ""}>
                            {rankedUser.username}
                          </span>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 border border-[#1a2a3a]">
                      {rankedUser.username !== "" ? rankedUser.level : ""}
                    </td>
                    <td className="py-3 px-4 border border-[#1a2a3a]">
                      {rankedUser.username !== "" ? rankedUser.rank : ""}
                    </td>
                    <td className="py-3 px-4 border border-[#1a2a3a]">
                      {rankedUser.username !== "" ? rankedUser.totalXp.toLocaleString() : ""}
                    </td>
                    <td className="py-3 px-4 border border-[#1a2a3a]">
                      {rankedUser.username !== ""
                        ? rankedUser.country === "Select"
                          ? "Select Country"
                          : rankedUser.country
                        : ""}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 p-4 bg-[#0a1220] rounded-lg">
            <h2 className="text-lg font-medium text-cyan-400 mb-2">Your Stats</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="text-sm text-gray-400">Strength</div>
                <div className="text-xl font-medium">{user.strength}</div>
              </div>
              <div>
                <div className="text-sm text-gray-400">Speed</div>
                <div className="text-xl font-medium">{user.speed}</div>
              </div>
              <div>
                <div className="text-sm text-gray-400">Health</div>
                <div className="text-xl font-medium">{user.health}</div>
              </div>
              <div>
                <div className="text-sm text-gray-400">Defence</div>
                <div className="text-xl font-medium">{user.defence}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
