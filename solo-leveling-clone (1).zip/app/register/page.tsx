"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

export default function RegisterPage() {
  const router = useRouter()
  const { register } = useAuth()
  const { toast } = useToast()
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [registrationStatus, setRegistrationStatus] = useState<"idle" | "success" | "error">("idle")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setRegistrationStatus("idle")

    // Simple validation
    if (!formData.username || !formData.email || !formData.password || !formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Passwords do not match",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email)) {
      toast({
        title: "Error",
        description: "Please enter a valid email address",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    try {
      // Attempt registration
      const success = register(formData.username, formData.email, formData.password)

      if (success) {
        setRegistrationStatus("success")
        toast({
          title: "Success",
          description: "Account created successfully",
        })

        // Check if users are saved
        const users = JSON.parse(localStorage.getItem("users") || "[]")
        console.log("Users after registration:", users)

        router.push("/")
      } else {
        setRegistrationStatus("error")
        toast({
          title: "Error",
          description: "Username or email already exists",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Registration error:", error)
      setRegistrationStatus("error")
      toast({
        title: "Error",
        description: "An unexpected error occurred during registration",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a1220] text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-cyan-400">Solo Leveling</h1>
          <p className="text-gray-400 mt-2">Create an account to start your journey</p>
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-1">
                Username
              </label>
              <input
                id="username"
                name="username"
                type="text"
                value={formData.username}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-[#0a1220] border border-[#1a2a3a] rounded-md text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="Choose a username"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-[#0a1220] border border-[#1a2a3a] rounded-md text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-[#0a1220] border border-[#1a2a3a] rounded-md text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 pr-10"
                  placeholder="Create a password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-300 mb-1">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-[#0a1220] border border-[#1a2a3a] rounded-md text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="Confirm your password"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-2 rounded-md font-medium transition-colors disabled:opacity-50"
            >
              {isLoading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          <div className="mt-4 text-center text-sm text-gray-400">
            <p>
              Already have an account?{" "}
              <Link href="/login" className="text-cyan-400 hover:underline">
                Sign In
              </Link>
            </p>
          </div>

          {registrationStatus === "success" && (
            <div className="mt-4 p-3 bg-green-500/20 text-green-400 rounded-md text-sm">
              Registration successful! Redirecting to home page...
            </div>
          )}

          {registrationStatus === "error" && (
            <div className="mt-4 p-3 bg-red-500/20 text-red-400 rounded-md text-sm">
              Registration failed. Please try again with different credentials.
            </div>
          )}
        </div>

        <div className="mt-4 text-center">
          <Link href="/admin" className="text-xs text-gray-500 hover:text-cyan-400">
            View Registered Users (Admin)
          </Link>
        </div>
      </div>
    </div>
  )
}
