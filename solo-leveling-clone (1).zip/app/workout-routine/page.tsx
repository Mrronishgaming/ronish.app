"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, CheckCircle, Circle, Clock, Play, Pause, RotateCcw } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { AnimatedNotification } from "@/components/ui/animated-notification"

// Define workout section types
type WorkoutSection = {
  title: string
  exercises: Exercise[]
}

type Exercise = {
  name: string
  duration: string // Can be reps (e.g., "3") or time (e.g., "30s")
  rest?: string // Rest period after exercise
  sets?: number // Number of sets (if applicable)
  completed: boolean
  currentSet?: number // Track current set progress
}

export default function WorkoutRoutinePage() {
  const router = useRouter()
  const { user, isAuthenticated, addXp, recordWorkout } = useAuth()
  const { toast } = useToast()
  const [activeExerciseIndex, setActiveExerciseIndex] = useState<number | null>(null)
  const [activeSectionIndex, setActiveSectionIndex] = useState<number>(0)
  const [timer, setTimer] = useState<number>(0)
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false)
  const [workoutComplete, setWorkoutComplete] = useState<boolean>(false)
  const [workoutStarted, setWorkoutStarted] = useState<boolean>(false)
  const [shouldMoveToNext, setShouldMoveToNext] = useState<boolean>(false)

  // Add state for notifications
  const [notifications, setNotifications] = useState<
    {
      type: "level-up" | "rank-up"
      title: string
      message: string
      id: string
    }[]
  >([])

  // Parse the workout data
  const [workoutSections, setWorkoutSections] = useState<WorkoutSection[]>([
    {
      title: "Warm Up",
      exercises: [
        { name: "Jumping Jacks", duration: "20", completed: false },
        { name: "Wrist Roll", duration: "20", completed: false },
        { name: "Elbow Circle", duration: "20", completed: false },
        { name: "Arm Circle", duration: "20", completed: false },
        { name: "Active Bar Hang", duration: "10s", completed: false },
      ],
    },
    {
      title: "Workout",
      exercises: [
        { name: "Pullup", duration: "3", rest: "60s", sets: 3, completed: false, currentSet: 1 },
        { name: "Tuck Front Lever Raise", duration: "3", rest: "60s", sets: 3, completed: false, currentSet: 1 },
        { name: "Chin Up", duration: "3", rest: "60s", sets: 3, completed: false, currentSet: 1 },
        { name: "Body Row", duration: "3", rest: "60s", sets: 3, completed: false, currentSet: 1 },
      ],
    },
    {
      title: "Stretching",
      exercises: [
        { name: "Shoulder Extension", duration: "30s", completed: false },
        { name: "Wall Downdog", duration: "30s", completed: false },
        { name: "Twisted Downward Dog (each side)", duration: "30s", completed: false },
      ],
    },
  ])

  // Check authentication
  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer <= 1) {
            setIsTimerRunning(false)
            // Play sound when timer ends
            const audio = new Audio("/beep.mp3")
            audio.play().catch((e) => console.error("Error playing sound:", e))

            // Set flag to move to next exercise
            setShouldMoveToNext(true)

            return 0
          }
          return prevTimer - 1
        })
      }, 1000)
    } else if (timer === 0) {
      setIsTimerRunning(false)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isTimerRunning, timer])

  // Handle moving to next exercise after timer ends
  useEffect(() => {
    if (shouldMoveToNext && activeExerciseIndex !== null) {
      // Find the next exercise
      const nextExerciseIndex = findNextExercise(activeSectionIndex, activeExerciseIndex)
      if (nextExerciseIndex) {
        startExercise(nextExerciseIndex.sectionIndex, nextExerciseIndex.exerciseIndex)
      } else {
        setActiveExerciseIndex(null)
      }

      // Reset the flag
      setShouldMoveToNext(false)
    }
  }, [shouldMoveToNext, activeExerciseIndex, activeSectionIndex])

  // Add this function to remove notifications
  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  // Update the useEffect that checks if workout is complete
  useEffect(() => {
    const allCompleted = workoutSections.every((section) => section.exercises.every((exercise) => exercise.completed))

    if (allCompleted && workoutStarted && !workoutComplete) {
      setWorkoutComplete(true)

      // Record workout completion for achievements
      recordWorkout()

      // Award XP for completing the workout
      const xpGained = 10 // Ensure this is 10 XP per workout
      const leveledUp = addXp(xpGained)

      // Get the current rank before XP is added
      const currentRank = user.rank

      // Check if rank changed
      const newRank = determineRank(user.totalXp + xpGained)
      const rankChanged = newRank !== currentRank

      toast({
        title: "Workout Complete!",
        description: `You've completed the full workout routine! +${xpGained} XP gained.`,
      })

      // Show level up notification
      if (leveledUp) {
        setNotifications((prev) => [
          ...prev,
          {
            type: "level-up",
            title: "Level Up!",
            message: `Congratulations! You've reached level ${user.level + 1}! All stats increased by 1.`,
            id: Date.now().toString(),
          },
        ])
      }

      // Show rank up notification
      if (rankChanged) {
        setNotifications((prev) => [
          ...prev,
          {
            type: "rank-up",
            title: "Rank Up!",
            message: `Congratulations! You've achieved ${newRank}-Rank!`,
            id: (Date.now() + 1).toString(),
          },
        ])
      }
    }
  }, [workoutSections, workoutStarted, workoutComplete, user, addXp, toast, recordWorkout])

  // Add the helper function to determine rank
  const determineRank = (totalXp: number): string => {
    if (totalXp < 10) return "Unranked"
    if (totalXp < 100) return "F"
    if (totalXp < 200) return "E"
    if (totalXp < 300) return "D"
    if (totalXp < 400) return "C"
    if (totalXp < 500) return "A"
    if (totalXp < 900) return "S"
    return "S+"
  }

  const startTimer = (seconds: number) => {
    setTimer(seconds)
    setIsTimerRunning(true)
  }

  const toggleTimer = () => {
    setIsTimerRunning(!isTimerRunning)
  }

  const resetTimer = () => {
    setIsTimerRunning(false)

    // Extract the current rest time from the active exercise
    if (activeSectionIndex !== null && activeExerciseIndex !== null) {
      const exercise = workoutSections[activeSectionIndex].exercises[activeExerciseIndex]
      if (exercise.rest) {
        const seconds = Number.parseInt(exercise.rest.replace("s", ""))
        setTimer(seconds)
      }
    }
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const startExercise = (sectionIndex: number, exerciseIndex: number) => {
    if (!workoutStarted) setWorkoutStarted(true)

    setActiveSectionIndex(sectionIndex)
    setActiveExerciseIndex(exerciseIndex)

    // If the exercise has a rest period, set up the timer
    const exercise = workoutSections[sectionIndex].exercises[exerciseIndex]
    if (exercise.rest) {
      const seconds = Number.parseInt(exercise.rest.replace("s", ""))
      startTimer(seconds)
    }
  }

  const completeExercise = (sectionIndex: number, exerciseIndex: number) => {
    const updatedSections = [...workoutSections]
    const exercise = updatedSections[sectionIndex].exercises[exerciseIndex]

    // If exercise has sets, increment the current set or mark as completed
    if (exercise.sets && exercise.currentSet) {
      if (exercise.currentSet < exercise.sets) {
        exercise.currentSet += 1
      } else {
        exercise.completed = true
      }
    } else {
      exercise.completed = true
    }

    setWorkoutSections(updatedSections)

    // If there's a rest period, start it
    if (exercise.rest) {
      const seconds = Number.parseInt(exercise.rest.replace("s", ""))
      startTimer(seconds)
    } else {
      // Otherwise, set flag to move to next exercise
      setShouldMoveToNext(true)
    }
  }

  const findNextExercise = (currentSectionIndex: number, currentExerciseIndex: number) => {
    const currentSection = workoutSections[currentSectionIndex]

    // Check if there's another exercise in the current section
    if (currentExerciseIndex < currentSection.exercises.length - 1) {
      return { sectionIndex: currentSectionIndex, exerciseIndex: currentExerciseIndex + 1 }
    }

    // Check if there's another section
    if (currentSectionIndex < workoutSections.length - 1) {
      return { sectionIndex: currentSectionIndex + 1, exerciseIndex: 0 }
    }

    return null // No more exercises
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-[#0a1220] text-white pb-20">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        <div className="flex items-center mb-6">
          <Link href="/workout" className="text-cyan-400 hover:text-cyan-300 mr-4">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-cyan-400">Pull Workout Routine</h1>
        </div>

        {/* Timer Display */}
        {isTimerRunning || timer > 0 ? (
          <div className="bg-[#0f1c2e] rounded-lg p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center">
              <Clock className="w-5 h-5 text-cyan-400 mr-2" />
              <span className="text-xl font-bold">{formatTime(timer)}</span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={toggleTimer}
                className="p-2 bg-cyan-500/20 text-cyan-400 rounded-md hover:bg-cyan-500/30 transition-colors"
              >
                {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <button
                onClick={resetTimer}
                className="p-2 bg-cyan-500/20 text-cyan-400 rounded-md hover:bg-cyan-500/30 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : null}

        {/* Workout Complete Message */}
        {workoutComplete && (
          <div className="bg-cyan-500/20 text-cyan-400 rounded-lg p-4 mb-6">
            <h2 className="text-lg font-bold flex items-center">
              <CheckCircle className="w-5 h-5 mr-2" />
              Workout Complete!
            </h2>
            <p className="mt-2">
              Great job! You've completed the entire workout routine. Take some time to recover before your next
              session.
            </p>
          </div>
        )}

        {/* Workout Sections */}
        {workoutSections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
            <h2 className="text-lg font-bold text-cyan-400 mb-4">{section.title}</h2>

            <div className="space-y-4">
              {section.exercises.map((exercise, exerciseIndex) => {
                const isActive = activeSectionIndex === sectionIndex && activeExerciseIndex === exerciseIndex
                const showSets = exercise.sets && exercise.sets > 1

                return (
                  <div
                    key={exerciseIndex}
                    className={`p-4 rounded-lg ${
                      exercise.completed
                        ? "bg-green-500/10 border border-green-500/30"
                        : isActive
                          ? "bg-cyan-500/10 border border-cyan-500/30"
                          : "bg-[#0a1220] border border-transparent"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        {exercise.completed ? (
                          <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                        ) : (
                          <Circle className="w-5 h-5 text-gray-400 mr-3" />
                        )}
                        <div>
                          <h3 className="font-medium">
                            {exercise.name}
                            {showSets && !exercise.completed && exercise.currentSet && (
                              <span className="text-cyan-400 ml-2">
                                Set {exercise.currentSet}/{exercise.sets}
                              </span>
                            )}
                          </h3>
                          <div className="flex text-sm text-gray-400 mt-1">
                            <span>{exercise.duration}</span>
                            {exercise.rest && <span className="ml-2">Rest: {exercise.rest}</span>}
                          </div>
                        </div>
                      </div>

                      {!exercise.completed && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => startExercise(sectionIndex, exerciseIndex)}
                            className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded-md text-sm hover:bg-cyan-500/30 transition-colors"
                          >
                            {isActive ? "Active" : "Start"}
                          </button>
                          {isActive && (
                            <button
                              onClick={() => completeExercise(sectionIndex, exerciseIndex)}
                              className="px-3 py-1 bg-green-500/20 text-green-400 rounded-md text-sm hover:bg-green-500/30 transition-colors"
                            >
                              {showSets && exercise.currentSet && exercise.currentSet < exercise.sets
                                ? "Next Set"
                                : "Complete"}
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        ))}

        {/* Start/Reset Buttons */}
        <div className="flex justify-center gap-4">
          {!workoutStarted ? (
            <button
              onClick={() => startExercise(0, 0)}
              className="px-6 py-2 bg-cyan-600 hover:bg-cyan-700 rounded-md font-medium transition-colors"
            >
              Start Workout
            </button>
          ) : (
            <button
              onClick={() => {
                if (confirm("Are you sure you want to reset the workout? All progress will be lost.")) {
                  // Reset the workout
                  const resetSections = workoutSections.map((section) => ({
                    ...section,
                    exercises: section.exercises.map((exercise) => ({
                      ...exercise,
                      completed: false,
                      currentSet: exercise.sets ? 1 : undefined,
                    })),
                  }))
                  setWorkoutSections(resetSections)
                  setActiveExerciseIndex(null)
                  setWorkoutComplete(false)
                  setWorkoutStarted(false)
                  setTimer(0)
                  setIsTimerRunning(false)
                }
              }}
              className="px-6 py-2 bg-red-600 hover:bg-red-700 rounded-md font-medium transition-colors"
            >
              Reset Workout
            </button>
          )}
        </div>
      </div>
      {notifications.map((notification) => (
        <AnimatedNotification
          key={notification.id}
          type={notification.type}
          title={notification.title}
          message={notification.message}
          onClose={() => removeNotification(notification.id)}
        />
      ))}
    </div>
  )
}
