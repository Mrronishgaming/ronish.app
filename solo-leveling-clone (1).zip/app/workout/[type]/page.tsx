"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  CheckCircle,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Lock,
  Timer,
  ArrowRightCircle,
  XCircle,
} from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { AnimatedNotification } from "@/components/ui/animated-notification"
import {
  getWorkoutData,
  getAvailableLevels,
  type WorkoutType,
  type DifficultyLevel,
  type Exercise,
} from "@/lib/workout-data"

type WorkoutExercise = Exercise & {
  completed: boolean
  currentSet?: number
}

type WorkoutSectionState = {
  title: string
  exercises: WorkoutExercise[]
}

type FlatExercise = WorkoutExercise & {
  sectionTitle: string
  sectionIndex: number
  exerciseIndex: number
}

export default function WorkoutPage({ params }: { params: { type: string } }) {
  const router = useRouter()
  const { user, isAuthenticated, addXp, recordWorkout, recordWorkoutCompletion } = useAuth()
  const { toast } = useToast()
  const [selectedLevel, setSelectedLevel] = useState<DifficultyLevel>("beginner")
  const [availableLevels, setAvailableLevels] = useState<DifficultyLevel[]>([])
  const [workoutSections, setWorkoutSections] = useState<WorkoutSectionState[]>([])
  const [flattenedExercises, setFlattenedExercises] = useState<FlatExercise[]>([])
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState<number>(0)
  const [workoutStarted, setWorkoutStarted] = useState<boolean>(false)
  const [workoutComplete, setWorkoutComplete] = useState<boolean>(false)
  const [timer, setTimer] = useState<number>(0)
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false)
  const [isRestPeriod, setIsRestPeriod] = useState<boolean>(false)
  const [shouldMoveToNext, setShouldMoveToNext] = useState<boolean>(false)
  const [notifications, setNotifications] = useState<
    {
      type: "level-up" | "rank-up"
      title: string
      message: string
      id: string
    }[]
  >([])
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [redirecting, setRedirecting] = useState(false)

  // Validate workout type
  const workoutType = params.type as WorkoutType
  const isValidWorkoutType = ["push", "pull", "abslegs"].includes(workoutType)

  useEffect(() => {
    // Initialize audio
    audioRef.current = new Audio("/beep.mp3")

    if (!isAuthenticated()) {
      router.push("/login")
      return
    }

    if (!isValidWorkoutType) {
      router.push("/workout")
      return
    }

    // Check if there's an active cooldown for this workout type
    const cooldownData = localStorage.getItem("workoutCooldowns")
    if (cooldownData) {
      const cooldowns = JSON.parse(cooldownData)
      const now = Date.now()

      if (cooldowns[workoutType] && cooldowns[workoutType] > now) {
        const timeRemaining = cooldowns[workoutType] - now
        const hours = Math.floor(timeRemaining / (1000 * 60 * 60))
        const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60))

        toast({
          title: "Workout Cooldown",
          description: `You're still recovering from your ${workoutType} workout. Try again in ${hours}h ${minutes}m.`,
          variant: "destructive",
        })
        router.push("/workout")
        return
      }
    }

    // Get available levels for this workout type
    const levels = getAvailableLevels(workoutType)
    setAvailableLevels(levels)

    // Check which levels are unlocked
    if (user) {
      const completionsData = localStorage.getItem(`${user.id}_workoutCompletions`)
      let completions: Record<string, number> = {}

      if (completionsData) {
        completions = JSON.parse(completionsData)
      }

      // Set the highest unlocked level as default
      if (completions[`${workoutType}_beginner`] >= 15 && levels.includes("intermediate")) {
        if (completions[`${workoutType}_intermediate`] >= 30 && levels.includes("advanced")) {
          setSelectedLevel("advanced")
        } else {
          setSelectedLevel("intermediate")
        }
      } else {
        setSelectedLevel("beginner")
      }
    }
  }, [isAuthenticated, router, workoutType, isValidWorkoutType, user, toast])

  // Load workout data when level changes
  useEffect(() => {
    if (!isValidWorkoutType || !selectedLevel) return

    try {
      const workoutData = getWorkoutData(workoutType, selectedLevel)

      // Initialize workout sections with completed state
      const initializedSections = workoutData.sections.map((section) => ({
        title: section.title,
        exercises: section.exercises.map((exercise) => ({
          ...exercise,
          completed: false,
          currentSet: exercise.sets ? 1 : undefined,
        })),
      }))

      setWorkoutSections(initializedSections)

      // Flatten exercises for sequential navigation
      const flattened: FlatExercise[] = []
      initializedSections.forEach((section, sectionIndex) => {
        section.exercises.forEach((exercise, exerciseIndex) => {
          flattened.push({
            ...exercise,
            sectionTitle: section.title,
            sectionIndex,
            exerciseIndex,
          })
        })
      })
      setFlattenedExercises(flattened)
      setCurrentExerciseIndex(0)
    } catch (error) {
      console.error("Error loading workout data:", error)
      toast({
        title: "Error",
        description: "Failed to load workout data. Please try again.",
        variant: "destructive",
      })
    }
  }, [selectedLevel, workoutType, isValidWorkoutType, toast])

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer <= 1) {
            setIsTimerRunning(false)
            // Play sound when timer ends
            if (audioRef.current) {
              audioRef.current.play().catch((e) => console.error("Error playing sound:", e))
            }

            // Instead of directly calling functions, set flags
            if (!isRestPeriod) {
              // For exercise completion
              completeCurrentExercise()
            } else {
              // For rest period completion
              setShouldMoveToNext(true)
            }

            return 0
          }
          return prevTimer - 1
        })
      }, 1000)
    } else if (timer === 0) {
      setIsTimerRunning(false)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isTimerRunning, timer, isRestPeriod])

  // Handle moving to next exercise after rest period
  useEffect(() => {
    if (shouldMoveToNext) {
      setIsRestPeriod(false)
      moveToNextExercise()
      setShouldMoveToNext(false)
    }
  }, [shouldMoveToNext])

  // Function to remove notifications
  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  // Check if workout is complete
  useEffect(() => {
    if (workoutComplete && user && !redirecting) {
      // Record workout completion
      recordWorkout()
      recordWorkoutCompletion(workoutType, selectedLevel)

      // Record completion for progression tracking
      const completionsData = localStorage.getItem(`${user.id}_workoutCompletions`)
      let completions: Record<string, number> = {}

      if (completionsData) {
        completions = JSON.parse(completionsData)
      }

      const key = `${workoutType}_${selectedLevel}`
      completions[key] = (completions[key] || 0) + 1

      localStorage.setItem(`${user.id}_workoutCompletions`, JSON.stringify(completions))

      // Set cooldown for this workout type (24 hours)
      const cooldownData = localStorage.getItem("workoutCooldowns") || "{}"
      const cooldowns = JSON.parse(cooldownData)
      cooldowns[workoutType] = Date.now() + 24 * 60 * 60 * 1000 // 24 hours
      localStorage.setItem("workoutCooldowns", JSON.stringify(cooldowns))

      // Check if this completion unlocks a new level
      const beginnerCompletions = completions[`${workoutType}_beginner`] || 0
      const intermediateCompletions = completions[`${workoutType}_intermediate`] || 0

      let unlockMessage = ""
      if (selectedLevel === "beginner" && beginnerCompletions >= 15 && beginnerCompletions - 1 < 15) {
        unlockMessage = "You've unlocked Intermediate difficulty!"
      } else if (
        selectedLevel === "intermediate" &&
        intermediateCompletions >= 30 &&
        intermediateCompletions - 1 < 30
      ) {
        unlockMessage = "You've unlocked Advanced difficulty!"
      }

      // Award XP for completing the workout
      const xpGained = 10
      const leveledUp = addXp(xpGained)

      // Get the current rank before XP is added
      const currentRank = user.rank

      // Check if rank changed
      const newRank = determineRank(user.totalXp + xpGained)
      const rankChanged = newRank !== currentRank

      toast({
        title: "Workout Complete!",
        description: `You've completed the ${selectedLevel} ${workoutType} workout! +${xpGained} XP gained.${unlockMessage ? " " + unlockMessage : ""}`,
      })

      // Show level up notification
      if (leveledUp) {
        setNotifications((prev) => [
          ...prev,
          {
            type: "level-up",
            title: "Level Up!",
            message: `Congratulations! You've reached level ${user.level + 1}! All stats increased by 1.`,
            id: Date.now().toString(),
          },
        ])
      }

      // Show rank up notification
      if (rankChanged) {
        setNotifications((prev) => [
          ...prev,
          {
            type: "rank-up",
            title: "Rank Up!",
            message: `Congratulations! You've achieved ${newRank}-Rank!`,
            id: (Date.now() + 1).toString(),
          },
        ])
      }

      // Show unlock notification if applicable
      if (unlockMessage) {
        setNotifications((prev) => [
          ...prev,
          {
            type: "level-up",
            title: "New Difficulty Unlocked!",
            message: unlockMessage,
            id: (Date.now() + 2).toString(),
          },
        ])
      }
    }
  }, [
    workoutComplete,
    user,
    addXp,
    toast,
    recordWorkout,
    recordWorkoutCompletion,
    workoutType,
    selectedLevel,
    redirecting,
  ])

  // Add this new useEffect after the existing workout completion useEffect
  useEffect(() => {
    // If workout is complete and not already redirecting, set up redirect
    if (workoutComplete && !redirecting) {
      setRedirecting(true)
      // Wait 3 seconds to allow notifications to be seen
      const redirectTimer = setTimeout(() => {
        router.push("/")
      }, 3000)

      return () => clearTimeout(redirectTimer)
    }
  }, [workoutComplete, router, redirecting])

  // Helper function to determine rank
  const determineRank = (totalXp: number): string => {
    if (totalXp < 10) return "Unranked"
    if (totalXp < 100) return "F"
    if (totalXp < 200) return "E"
    if (totalXp < 300) return "D"
    if (totalXp < 400) return "C"
    if (totalXp < 500) return "A"
    if (totalXp < 900) return "S"
    return "S+"
  }

  const startTimer = (seconds: number) => {
    setTimer(seconds)
    setIsTimerRunning(true)
  }

  const toggleTimer = () => {
    setIsTimerRunning(!isTimerRunning)
  }

  const resetTimer = () => {
    setIsTimerRunning(false)

    // Reset to the appropriate time based on current state
    if (isRestPeriod && currentExercise?.rest) {
      const seconds = Number.parseInt(currentExercise.rest.replace("s", ""))
      setTimer(seconds)
    } else if (currentExercise?.duration.endsWith("s")) {
      const seconds = Number.parseInt(currentExercise.duration.replace("s", ""))
      setTimer(seconds)
    }
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Start the workout
  const startWorkout = () => {
    setWorkoutStarted(true)
    setCurrentExerciseIndex(0)

    // If the first exercise is timed, start the timer
    const firstExercise = flattenedExercises[0]
    if (firstExercise && firstExercise.duration.endsWith("s")) {
      const seconds = Number.parseInt(firstExercise.duration.replace("s", ""))
      startTimer(seconds)
    }
  }

  // Get the current exercise
  const currentExercise = flattenedExercises[currentExerciseIndex]

  // Complete the current exercise
  const completeCurrentExercise = () => {
    if (!currentExercise) return

    // Update the exercise in the flattened list
    const updatedExercises = [...flattenedExercises]

    // If exercise has sets, increment the current set or mark as completed
    if (currentExercise.sets && currentExercise.currentSet) {
      if (currentExercise.currentSet < currentExercise.sets) {
        updatedExercises[currentExerciseIndex] = {
          ...currentExercise,
          currentSet: currentExercise.currentSet + 1,
        }
        setFlattenedExercises(updatedExercises)

        // If there's a rest period, start it
        if (currentExercise.rest) {
          setIsRestPeriod(true)
          const restSeconds = Number.parseInt(currentExercise.rest.replace("s", ""))
          startTimer(restSeconds)
        }
      } else {
        // Mark as completed and move to next exercise
        updatedExercises[currentExerciseIndex] = {
          ...currentExercise,
          completed: true,
        }
        setFlattenedExercises(updatedExercises)

        // Update in the original sections structure
        const updatedSections = [...workoutSections]
        updatedSections[currentExercise.sectionIndex].exercises[currentExercise.exerciseIndex].completed = true
        setWorkoutSections(updatedSections)

        // If there's a rest period, start it before moving to next exercise
        if (currentExercise.rest) {
          setIsRestPeriod(true)
          const restSeconds = Number.parseInt(currentExercise.rest.replace("s", ""))
          startTimer(restSeconds)
        } else {
          moveToNextExercise()
        }
      }
    } else {
      // Mark as completed and move to next exercise
      updatedExercises[currentExerciseIndex] = {
        ...currentExercise,
        completed: true,
      }
      setFlattenedExercises(updatedExercises)

      // Update in the original sections structure
      const updatedSections = [...workoutSections]
      updatedSections[currentExercise.sectionIndex].exercises[currentExercise.exerciseIndex].completed = true
      setWorkoutSections(updatedSections)

      // If there's a rest period, start it before moving to next exercise
      if (currentExercise.rest) {
        setIsRestPeriod(true)
        const restSeconds = Number.parseInt(currentExercise.rest.replace("s", ""))
        startTimer(restSeconds)
      } else {
        moveToNextExercise()
      }
    }
  }

  // Move to the next exercise
  const moveToNextExercise = () => {
    if (currentExerciseIndex < flattenedExercises.length - 1) {
      const nextIndex = currentExerciseIndex + 1
      setCurrentExerciseIndex(nextIndex)
      setIsRestPeriod(false)

      // If the next exercise is timed, start the timer
      const nextExercise = flattenedExercises[nextIndex]
      if (nextExercise && nextExercise.duration.endsWith("s")) {
        const seconds = Number.parseInt(nextExercise.duration.replace("s", ""))
        startTimer(seconds)
      } else {
        setTimer(0)
        setIsTimerRunning(false)
      }
    } else {
      // Workout complete
      setWorkoutComplete(true)
    }
  }

  // Move to the previous exercise
  const moveToPreviousExercise = () => {
    if (currentExerciseIndex > 0) {
      const prevIndex = currentExerciseIndex - 1
      setCurrentExerciseIndex(prevIndex)
      setIsRestPeriod(false)

      // Reset timer
      setTimer(0)
      setIsTimerRunning(false)

      // Mark the current exercise as not completed
      const updatedExercises = [...flattenedExercises]
      updatedExercises[currentExerciseIndex] = {
        ...currentExercise,
        completed: false,
        currentSet: currentExercise.sets ? 1 : undefined,
      }
      setFlattenedExercises(updatedExercises)

      // Update in the original sections structure
      const updatedSections = [...workoutSections]
      updatedSections[currentExercise.sectionIndex].exercises[currentExercise.exerciseIndex].completed = false
      updatedSections[currentExercise.sectionIndex].exercises[currentExercise.exerciseIndex].currentSet =
        currentExercise.sets ? 1 : undefined
      setWorkoutSections(updatedSections)
    }
  }

  // Start a timed exercise
  const startTimedExercise = () => {
    if (!currentExercise || !currentExercise.duration.endsWith("s")) return

    const seconds = Number.parseInt(currentExercise.duration.replace("s", ""))
    startTimer(seconds)
  }

  // Function to check if a level is unlocked
  const isLevelUnlocked = (level: DifficultyLevel): boolean => {
    if (level === "beginner") return true

    if (!user) return false

    const completionsData = localStorage.getItem(`${user.id}_workoutCompletions`)
    if (!completionsData) return false

    const completions = JSON.parse(completionsData)

    if (level === "intermediate") {
      return (completions[`${workoutType}_beginner`] || 0) >= 15
    }

    if (level === "advanced") {
      return (completions[`${workoutType}_intermediate`] || 0) >= 30
    }

    return false
  }

  // Add the helper function to get workout completions
  const getWorkoutCompletions = (type: string, level: string): number => {
    if (!user) return 0

    const completionsData = localStorage.getItem(`${user.id}_workoutCompletions`)
    if (!completionsData) return 0

    const completions = JSON.parse(completionsData)
    return completions[`${type}_${level}`] || 0
  }

  // Calculate progress percentage
  const calculateProgress = () => {
    if (flattenedExercises.length === 0) return 0
    const completedExercises = flattenedExercises.filter((ex) => ex.completed).length
    return (completedExercises / flattenedExercises.length) * 100
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-[#0a1220] text-white pb-20">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        <div className="flex items-center mb-6">
          <Link href="/workout" className="text-cyan-400 hover:text-cyan-300 mr-4">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-cyan-400">
            {workoutType.charAt(0).toUpperCase() + workoutType.slice(1)} Workout
          </h1>
        </div>

        {/* Difficulty Level Selector - Only show before workout starts */}
        {!workoutStarted && !workoutComplete && (
          <div className="bg-[#0f1c2e] rounded-lg p-4 mb-6">
            <h2 className="text-lg font-bold text-cyan-400 mb-3">Select Difficulty</h2>

            <div className="space-y-4">
              {availableLevels.map((level) => {
                const isUnlocked = isLevelUnlocked(level)
                const completions = getWorkoutCompletions(workoutType, level)
                let progressPercentage = 0
                let targetCompletions = 0

                if (level === "beginner") {
                  targetCompletions = 15
                  progressPercentage = Math.min((completions / targetCompletions) * 100, 100)
                } else if (level === "intermediate") {
                  targetCompletions = 30
                  progressPercentage = Math.min((completions / targetCompletions) * 100, 100)
                } else if (level === "advanced") {
                  progressPercentage = completions > 0 ? 100 : 0
                }

                return (
                  <div key={level} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <button
                          onClick={() => isUnlocked && setSelectedLevel(level)}
                          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                            selectedLevel === level
                              ? "bg-cyan-600 text-white"
                              : isUnlocked
                                ? "bg-[#0a1220] text-gray-300 hover:bg-cyan-600/20"
                                : "bg-[#0a1220] text-gray-500 opacity-50 cursor-not-allowed"
                          }`}
                          disabled={!isUnlocked}
                        >
                          {level.charAt(0).toUpperCase() + level.slice(1)}
                          {!isUnlocked && <Lock className="inline-block w-3 h-3 ml-1" />}
                        </button>
                      </div>

                      <span className="text-xs text-cyan-400">
                        {level === "beginner"
                          ? `${completions}/15 to unlock Intermediate`
                          : level === "intermediate"
                            ? `${completions}/30 to unlock Advanced`
                            : `${completions} completed`}
                      </span>
                    </div>

                    <div className="h-2 bg-[#0a1220] rounded-full overflow-hidden">
                      <div
                        className={`h-full ${isUnlocked ? "bg-cyan-500" : "bg-gray-600"}`}
                        style={{ width: `${progressPercentage}%` }}
                      ></div>
                    </div>
                  </div>
                )
              })}
            </div>

            <div className="mt-6">
              <button
                onClick={startWorkout}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-3 rounded-md font-medium transition-colors flex items-center justify-center"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Workout
              </button>
            </div>
          </div>
        )}

        {/* Workout Complete Message */}
        {workoutComplete && (
          <div className="bg-cyan-500/20 text-cyan-400 rounded-lg p-6 mb-6">
            <h2 className="text-xl font-bold flex items-center justify-center mb-4">
              <CheckCircle className="w-6 h-6 mr-2" />
              Workout Complete!
            </h2>
            <p className="text-center mb-6">
              Great job! You've completed the entire workout routine. Take some time to recover before your next
              session.
            </p>

            <div className="flex justify-center">
              <Link
                href="/workout"
                className="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-2 rounded-md font-medium transition-colors"
              >
                Return to Workouts
              </Link>
            </div>
          </div>
        )}

        {/* Active Workout View */}
        {workoutStarted && !workoutComplete && currentExercise && (
          <>
            {/* Progress Bar */}
            <div className="bg-[#0f1c2e] rounded-lg p-4 mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span>Progress</span>
                <span>
                  {flattenedExercises.filter((ex) => ex.completed).length}/{flattenedExercises.length} exercises
                </span>
              </div>
              <div className="h-2 bg-[#0a1220] rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-500 transition-all duration-300"
                  style={{ width: `${calculateProgress()}%` }}
                ></div>
              </div>
            </div>

            {/* Current Exercise Card */}
            <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
              <div className="text-sm text-cyan-400 mb-2">{currentExercise.sectionTitle}</div>

              <h2 className="text-2xl font-bold mb-4">
                {currentExercise.name}
                {currentExercise.sets && (
                  <span className="ml-2 text-lg text-cyan-400">
                    Set {currentExercise.currentSet}/{currentExercise.sets}
                  </span>
                )}
              </h2>

              <div className="flex items-center mb-6">
                <div
                  className={`px-3 py-1 rounded-full text-sm ${isRestPeriod ? "bg-amber-500/20 text-amber-400" : "bg-cyan-500/20 text-cyan-400"}`}
                >
                  {isRestPeriod ? (
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      <span>Rest: {currentExercise.rest}</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <Timer className="w-4 h-4 mr-1" />
                      <span>Duration: {currentExercise.duration}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Timer Display */}
              {((isRestPeriod && currentExercise.rest) ||
                (!isRestPeriod && currentExercise.duration.endsWith("s"))) && (
                <div className="bg-[#0a1220] rounded-lg p-6 mb-6 flex flex-col items-center">
                  <div className="text-sm mb-2">{isRestPeriod ? "Rest Time Remaining" : "Exercise Time Remaining"}</div>
                  <div className="text-4xl font-bold mb-4">{formatTime(timer)}</div>
                  <div className="flex gap-3">
                    <button
                      onClick={toggleTimer}
                      className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors"
                    >
                      {isTimerRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                    </button>
                    <button
                      onClick={resetTimer}
                      className="px-4 py-2 bg-slate-600 text-white rounded-md hover:bg-slate-700 transition-colors"
                    >
                      <RotateCcw className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Exercise Controls */}
              <div className="flex justify-between">
                <button
                  onClick={moveToPreviousExercise}
                  disabled={currentExerciseIndex === 0}
                  className={`px-4 py-2 rounded-md ${
                    currentExerciseIndex === 0
                      ? "bg-slate-700 text-slate-500 cursor-not-allowed"
                      : "bg-slate-600 text-white hover:bg-slate-700"
                  }`}
                >
                  Previous
                </button>

                <div className="flex gap-3">
                  {!isRestPeriod && currentExercise.duration.endsWith("s") && !isTimerRunning && timer === 0 && (
                    <button
                      onClick={startTimedExercise}
                      className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors"
                    >
                      Start Timer
                    </button>
                  )}

                  {!isRestPeriod && (
                    <button
                      onClick={completeCurrentExercise}
                      className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                    >
                      Complete Exercise
                    </button>
                  )}
                </div>

                <button
                  onClick={moveToNextExercise}
                  disabled={currentExerciseIndex === flattenedExercises.length - 1}
                  className={`px-4 py-2 rounded-md ${
                    currentExerciseIndex === flattenedExercises.length - 1
                      ? "bg-slate-700 text-slate-500 cursor-not-allowed"
                      : "bg-slate-600 text-white hover:bg-slate-700"
                  }`}
                >
                  Skip
                </button>
              </div>
            </div>

            {/* Next Exercise Preview */}
            {currentExerciseIndex < flattenedExercises.length - 1 && (
              <div className="bg-[#0f1c2e] rounded-lg p-4 mb-6">
                <div className="text-sm text-gray-400 mb-1">Next Exercise</div>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{flattenedExercises[currentExerciseIndex + 1].name}</h3>
                    <div className="text-sm text-gray-400">
                      {flattenedExercises[currentExerciseIndex + 1].duration}
                      {flattenedExercises[currentExerciseIndex + 1].rest &&
                        ` (Rest: ${flattenedExercises[currentExerciseIndex + 1].rest})`}
                    </div>
                  </div>
                  <ArrowRightCircle className="w-5 h-5 text-cyan-400" />
                </div>
              </div>
            )}

            {/* Exit Workout Button */}
            <button
              onClick={() => {
                if (confirm("Are you sure you want to exit the workout? Your progress will be lost.")) {
                  router.push("/workout")
                }
              }}
              className="w-full py-2 bg-red-600/20 text-red-400 rounded-md hover:bg-red-600/30 transition-colors flex items-center justify-center"
            >
              <XCircle className="w-5 h-5 mr-2" />
              Exit Workout
            </button>
          </>
        )}
      </div>

      {notifications.map((notification) => (
        <AnimatedNotification
          key={notification.id}
          type={notification.type}
          title={notification.title}
          message={notification.message}
          onClose={() => removeNotification(notification.id)}
        />
      ))}
    </div>
  )
}
