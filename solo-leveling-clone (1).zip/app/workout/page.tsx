"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Dumbbell, Heart, Shield, Zap, Clock, CheckCircle } from "lucide-react"
import Image from "next/image"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

export default function WorkoutPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const { toast } = useToast()
  const [activeCooldown, setActiveCooldown] = useState<string | null>(null)
  const [cooldownTimes, setCooldownTimes] = useState<Record<string, number>>({})

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/login")
    }

    // Check for active cooldowns
    const cooldownData = localStorage.getItem("workoutCooldowns")
    if (cooldownData) {
      const cooldowns = JSON.parse(cooldownData)
      const now = Date.now()
      const activeCooldowns: Record<string, number> = {}

      // Find any active cooldown
      for (const [type, time] of Object.entries(cooldowns)) {
        if ((time as number) > now) {
          if (!activeCooldown) {
            setActiveCooldown(type)
          }

          activeCooldowns[type] = (time as number) - now

          // Set a timeout to clear the cooldown when it expires
          const timeRemaining = (time as number) - now
          setTimeout(() => {
            setCooldownTimes((prev) => {
              const updated = { ...prev }
              delete updated[type]
              return updated
            })

            if (activeCooldown === type) {
              setActiveCooldown(null)
            }
          }, timeRemaining)
        }
      }

      setCooldownTimes(activeCooldowns)
    }
  }, [isAuthenticated, router, activeCooldown])

  // Format time for cooldown display
  const formatCooldownTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60))
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60))
    const seconds = Math.floor((ms % (1000 * 60)) / 1000)

    if (hours > 0) {
      return `${hours}h ${minutes}m`
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`
    } else {
      return `${seconds}s`
    }
  }

  // Check if a workout was completed today
  const wasWorkoutCompletedToday = (type: string): boolean => {
    if (!user) return false

    const cooldownData = localStorage.getItem("workoutCooldowns")
    if (!cooldownData) return false

    const cooldowns = JSON.parse(cooldownData)
    return !!cooldowns[type]
  }

  // Function to handle workout selection
  const handleWorkoutSelect = (type: string) => {
    if (cooldownTimes[type]) {
      toast({
        title: "Workout Cooldown",
        description: `You're still recovering from your ${type} workout. Try again in ${formatCooldownTime(cooldownTimes[type])}.`,
        variant: "destructive",
      })
      return
    }

    router.push(`/workout/${type}`)
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-[#0a1220] text-white">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        {/* User Profile Section */}
        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6 flex items-center">
          <div className="relative w-16 h-16 rounded-full overflow-hidden mr-4 border-2 border-cyan-500">
            {user.profilePicture && (
              <Image
                src={user.profilePicture || "/placeholder.svg"}
                alt={user.username}
                fill
                className="object-cover"
              />
            )}
          </div>
          <div>
            <h2 className="text-xl font-bold">{user.username}</h2>
            <div className="flex items-center text-sm text-gray-400">
              <span className="mr-3">Level {user.level}</span>
              <span className="mr-3">{user.rank}-Rank</span>
              <span>Workouts: {user.workoutsCompleted || 0}</span>
            </div>
          </div>
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6 mb-6">
          <h1 className="text-2xl font-bold text-cyan-400 mb-4">Training Center</h1>
          <p className="text-gray-300 mb-6">
            Choose a workout type to improve your stats. Each workout has a 24-hour cooldown period.
          </p>

          {/* Workout Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Push Workout */}
            <div
              className={`bg-[#0a1220] rounded-lg p-6 border border-transparent hover:border-cyan-500/30 transition-colors cursor-pointer ${cooldownTimes["push"] ? "opacity-80" : ""}`}
              onClick={() => handleWorkoutSelect("push")}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mr-4">
                  <Dumbbell className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold">Push Workout</h2>
                  <p className="text-sm text-gray-400">Chest, Shoulders, Triceps</p>
                </div>

                {wasWorkoutCompletedToday("push") && (
                  <div className="ml-auto">
                    <div className="bg-green-500/20 text-green-400 p-1 rounded-full">
                      <CheckCircle className="w-5 h-5" />
                    </div>
                  </div>
                )}
              </div>

              {cooldownTimes["push"] ? (
                <div className="bg-[#0f1c2e] rounded-lg p-3 mb-4">
                  <div className="flex items-center text-amber-400">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>Rest time: {formatCooldownTime(cooldownTimes["push"])}</span>
                  </div>
                </div>
              ) : (
                <div className="h-[52px] mb-4"></div> // Placeholder to maintain layout
              )}

              <div className="flex justify-between items-center">
                <span className="text-sm text-cyan-400">+10 XP on completion</span>
                <span className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded-md text-sm">Start</span>
              </div>
            </div>

            {/* Pull Workout */}
            <div
              className={`bg-[#0a1220] rounded-lg p-6 border border-transparent hover:border-cyan-500/30 transition-colors cursor-pointer ${cooldownTimes["pull"] ? "opacity-80" : ""}`}
              onClick={() => handleWorkoutSelect("pull")}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mr-4">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold">Pull Workout</h2>
                  <p className="text-sm text-gray-400">Back, Biceps, Forearms</p>
                </div>

                {wasWorkoutCompletedToday("pull") && (
                  <div className="ml-auto">
                    <div className="bg-green-500/20 text-green-400 p-1 rounded-full">
                      <CheckCircle className="w-5 h-5" />
                    </div>
                  </div>
                )}
              </div>

              {cooldownTimes["pull"] ? (
                <div className="bg-[#0f1c2e] rounded-lg p-3 mb-4">
                  <div className="flex items-center text-amber-400">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>Rest time: {formatCooldownTime(cooldownTimes["pull"])}</span>
                  </div>
                </div>
              ) : (
                <div className="h-[52px] mb-4"></div> // Placeholder to maintain layout
              )}

              <div className="flex justify-between items-center">
                <span className="text-sm text-cyan-400">+10 XP on completion</span>
                <span className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded-md text-sm">Start</span>
              </div>
            </div>

            {/* Abs/Legs Workout */}
            <div
              className={`bg-[#0a1220] rounded-lg p-6 border border-transparent hover:border-cyan-500/30 transition-colors cursor-pointer ${cooldownTimes["abslegs"] ? "opacity-80" : ""}`}
              onClick={() => handleWorkoutSelect("abslegs")}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center text-cyan-400 mr-4">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold">Abs/Legs Workout</h2>
                  <p className="text-sm text-gray-400">Core, Quads, Hamstrings, Calves</p>
                </div>

                {wasWorkoutCompletedToday("abslegs") && (
                  <div className="ml-auto">
                    <div className="bg-green-500/20 text-green-400 p-1 rounded-full">
                      <CheckCircle className="w-5 h-5" />
                    </div>
                  </div>
                )}
              </div>

              {cooldownTimes["abslegs"] ? (
                <div className="bg-[#0f1c2e] rounded-lg p-3 mb-4">
                  <div className="flex items-center text-amber-400">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>Rest time: {formatCooldownTime(cooldownTimes["abslegs"])}</span>
                  </div>
                </div>
              ) : (
                <div className="h-[52px] mb-4"></div> // Placeholder to maintain layout
              )}

              <div className="flex justify-between items-center">
                <span className="text-sm text-cyan-400">+10 XP on completion</span>
                <span className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded-md text-sm">Start</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6">
          <h2 className="text-lg font-bold text-cyan-400 mb-4">Your Current Stats</h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <div className="flex items-center mb-2">
                <Dumbbell className="w-4 h-4 text-cyan-400 mr-2" />
                <span className="text-sm">Strength</span>
              </div>
              <div className="text-2xl font-medium">{user.strength}</div>
            </div>

            <div>
              <div className="flex items-center mb-2">
                <Zap className="w-4 h-4 text-cyan-400 mr-2" />
                <span className="text-sm">Speed</span>
              </div>
              <div className="text-2xl font-medium">{user.speed}</div>
            </div>

            <div>
              <div className="flex items-center mb-2">
                <Heart className="w-4 h-4 text-cyan-400 mr-2" />
                <span className="text-sm">Health</span>
              </div>
              <div className="text-2xl font-medium">{user.health}</div>
            </div>

            <div>
              <div className="flex items-center mb-2">
                <Shield className="w-4 h-4 text-cyan-400 mr-2" />
                <span className="text-sm">Defence</span>
              </div>
              <div className="text-2xl font-medium">{user.defence}</div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-[#0a1220] rounded-lg">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Dumbbell className="w-5 h-5 text-cyan-400 mr-2" />
                <span className="text-lg font-medium">Total Workouts Completed</span>
              </div>
              <span className="text-2xl font-bold text-cyan-400">{user.workoutsCompleted || 0}</span>
            </div>
          </div>
        </div>

        <div className="bg-[#0f1c2e] rounded-lg p-6 mt-6">
          <h2 className="text-lg font-bold text-cyan-400 mb-4">Experience</h2>

          <div className="mb-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Level {user.level}</span>
              <span>
                {user.xp} / {user.level * 10} XP
              </span>
            </div>
            <div className="h-2 bg-[#0a1220] rounded-full overflow-hidden">
              <div className="h-full bg-cyan-500" style={{ width: `${(user.xp / (user.level * 10)) * 100}%` }}></div>
            </div>
            <p className="text-xs text-gray-400 mt-1">Each workout gives +10 XP</p>
            <p className="text-xs text-cyan-400 mt-1">Level up bonus: +1 to all stats!</p>
          </div>

          <div className="flex items-center justify-between bg-[#0a1220] p-3 rounded-lg">
            <div>
              <span className="text-sm">Current Rank:</span>
              <span className="ml-2 text-cyan-400 font-medium">{user.rank}-Rank</span>
            </div>
            <div>
              <span className="text-sm">Total XP:</span>
              <span className="ml-2 text-cyan-400 font-medium">{user.totalXp}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
