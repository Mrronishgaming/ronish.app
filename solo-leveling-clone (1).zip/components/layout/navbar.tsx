"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, User, Award, Dumbbell, LogOut, Settings } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

export default function Navbar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  // Don't show navbar on login or register pages
  if (pathname === "/login" || pathname === "/register") {
    return null
  }

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#0a1220] border-t border-[#1a2a3a] py-3 z-10">
      <div className="container mx-auto max-w-4xl px-4">
        <div className="flex justify-around items-center">
          <Link
            href="/"
            className={`flex flex-col items-center ${isActive("/") ? "text-cyan-400" : "text-gray-400 hover:text-cyan-400"} transition-colors`}
          >
            <Home className="w-5 h-5" />
            <span className="text-xs mt-1">Home</span>
          </Link>

          <Link
            href="/profile"
            className={`flex flex-col items-center ${isActive("/profile") ? "text-cyan-400" : "text-gray-400 hover:text-cyan-400"} transition-colors`}
          >
            <User className="w-5 h-5" />
            <span className="text-xs mt-1">Profile</span>
          </Link>

          <Link
            href="/rank"
            className={`flex flex-col items-center ${isActive("/rank") ? "text-cyan-400" : "text-gray-400 hover:text-cyan-400"} transition-colors`}
          >
            <Award className="w-5 h-5" />
            <span className="text-xs mt-1">Rank</span>
          </Link>

          <Link
            href="/workout"
            className={`flex flex-col items-center ${isActive("/workout") ? "text-cyan-400" : "text-gray-400 hover:text-cyan-400"} transition-colors`}
          >
            <Dumbbell className="w-5 h-5" />
            <span className="text-xs mt-1">Workout</span>
          </Link>

          {user && user.username === "Ronish" && (
            <Link
              href="/admin"
              className={`flex flex-col items-center ${isActive("/admin") ? "text-cyan-400" : "text-gray-400 hover:text-cyan-400"} transition-colors`}
            >
              <Settings className="w-5 h-5" />
              <span className="text-xs mt-1">Admin</span>
            </Link>
          )}

          {user && (
            <button
              onClick={logout}
              className="flex flex-col items-center text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span className="text-xs mt-1">Logout</span>
            </button>
          )}
        </div>
      </div>
    </nav>
  )
}
