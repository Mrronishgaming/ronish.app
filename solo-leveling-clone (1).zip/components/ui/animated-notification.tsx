"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Award, TrendingUp } from "lucide-react"

type NotificationType = "level-up" | "rank-up"

interface AnimatedNotificationProps {
  type: NotificationType
  title: string
  message: string
  onClose: () => void
  duration?: number // in milliseconds
}

export function AnimatedNotification({ type, title, message, onClose, duration = 5000 }: AnimatedNotificationProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
    }, duration)

    return () => clearTimeout(timer)
  }, [duration])

  const handleAnimationComplete = () => {
    if (!isVisible) {
      onClose()
    }
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 0, scale: 0.3 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5, y: 0 }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
          onAnimationComplete={handleAnimationComplete}
          className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-sm"
        >
          <div
            className={`rounded-lg shadow-lg p-4 ${
              type === "level-up"
                ? "bg-gradient-to-r from-cyan-600 to-blue-600"
                : "bg-gradient-to-r from-amber-500 to-orange-600"
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <motion.div
                  initial={{ rotate: 0 }}
                  animate={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
                >
                  {type === "level-up" ? (
                    <TrendingUp className="w-6 h-6 text-white" />
                  ) : (
                    <Award className="w-6 h-6 text-white" />
                  )}
                </motion.div>
              </div>
              <div className="ml-3 w-0 flex-1">
                <motion.div initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }}>
                  <p className="text-lg font-medium text-white">{title}</p>
                  <p className="mt-1 text-sm text-white/80">{message}</p>
                </motion.div>
              </div>
              <div className="ml-4 flex-shrink-0 flex">
                <button
                  onClick={() => setIsVisible(false)}
                  className="inline-flex text-white/60 hover:text-white focus:outline-none"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            <motion.div
              initial={{ width: "100%" }}
              animate={{ width: "0%" }}
              transition={{ duration: duration / 1000, ease: "linear" }}
              className="h-1 bg-white/30 mt-3 rounded-full"
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
