"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"

// Define achievement types
export type AchievementType = "join" | "first_workout" | "first_level_up" | "first_rank" | "rank_up" | "level_up"

export type Achievement = {
  id: string
  type: AchievementType
  title: string
  description: string
  date: string
  icon: string
  completed: boolean
  progress?: {
    current: number
    target: number
  }
}

type User = {
  id: string
  username: string
  email: string
  level: number
  rank: string
  strength: number
  speed: number
  health: number
  defence: number
  dungeonsCleared: number
  shadowSoldiers: number
  guildPosition: string
  xp: number
  totalXp: number
  registeredAt: string
  lastLogin: string
  country?: string
  profilePicture?: string
  achievements: Achievement[]
  workoutsCompleted: number
}

type LoginRecord = {
  userId: string
  username: string
  email: string
  timestamp: string
  ipAddress?: string
  device?: string
}

type AuthContextType = {
  user: User | null
  login: (email: string, password: string) => boolean
  register: (username: string, email: string, password: string) => boolean
  logout: () => void
  isAuthenticated: () => boolean
  updateStats: (stats: Partial<User>) => void
  addXp: (amount: number) => boolean | undefined
  getLoginHistory: () => LoginRecord[]
  updateUserProfile: (data: Partial<User>) => void
  unlockAchievement: (type: AchievementType, details?: any) => void
  recordWorkout: () => void
  recordWorkoutCompletion: (type: string, level: string) => void
}

// Solo Leveling character profile pictures
const defaultProfilePictures = [
  "/profile-pics/sung-jinwoo.jpg",
  "/profile-pics/cha-hae-in.jpg",
  "/profile-pics/go-gun-hee.jpg",
  "/profile-pics/woo-jin-chul.jpg",
  "/profile-pics/baek-yoonho.jpg",
  "/profile-pics/choi-jong-in.jpg",
  "/profile-pics/hwang-dongsoo.jpg",
  "/profile-pics/igris.jpg",
  "/profile-pics/beru.jpg",
  "/profile-pics/tusk.jpg",
  "/profile-pics/purple-shadow.jpeg",
  "/profile-pics/purple-glow.jpeg",
]

// Get a random profile picture
const getRandomProfilePic = () => {
  const randomIndex = Math.floor(Math.random() * defaultProfilePictures.length)
  return defaultProfilePictures[randomIndex]
}

// Default achievements
const defaultAchievements: Achievement[] = [
  {
    id: "join",
    type: "join",
    title: "Welcome, Hunter",
    description: "Join the world of Solo Leveling",
    date: "",
    icon: "user",
    completed: false,
  },
  {
    id: "first_workout",
    type: "first_workout",
    title: "First Steps",
    description: "Complete your first workout",
    date: "",
    icon: "dumbbell",
    completed: false,
  },
  {
    id: "first_level_up",
    type: "first_level_up",
    title: "Growing Stronger",
    description: "Reach level 2 for the first time",
    date: "",
    icon: "trending-up",
    completed: false,
  },
  {
    id: "first_rank",
    type: "first_rank",
    title: "Ranked Hunter",
    description: "Achieve your first rank",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_f",
    type: "rank_up",
    title: "F-Rank Hunter",
    description: "Achieve F-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_e",
    type: "rank_up",
    title: "E-Rank Hunter",
    description: "Achieve E-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_d",
    type: "rank_up",
    title: "D-Rank Hunter",
    description: "Achieve D-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_c",
    type: "rank_up",
    title: "C-Rank Hunter",
    description: "Achieve C-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_a",
    type: "rank_up",
    title: "A-Rank Hunter",
    description: "Achieve A-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_s",
    type: "rank_up",
    title: "S-Rank Hunter",
    description: "Achieve S-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "rank_s_plus",
    type: "rank_up",
    title: "S+-Rank Hunter",
    description: "Achieve S+-Rank status",
    date: "",
    icon: "award",
    completed: false,
  },
  {
    id: "level_5",
    type: "level_up",
    title: "Novice Hunter",
    description: "Reach level 5",
    date: "",
    icon: "trending-up",
    completed: false,
  },
  {
    id: "level_10",
    type: "level_up",
    title: "Experienced Hunter",
    description: "Reach level 10",
    date: "",
    icon: "trending-up",
    completed: false,
  },
  {
    id: "level_20",
    type: "level_up",
    title: "Veteran Hunter",
    description: "Reach level 20",
    date: "",
    icon: "trending-up",
    completed: false,
  },
  {
    id: "level_50",
    type: "level_up",
    title: "Elite Hunter",
    description: "Reach level 50",
    date: "",
    icon: "trending-up",
    completed: false,
  },
  {
    id: "level_100",
    type: "level_up",
    title: "Legendary Hunter",
    description: "Reach level 100",
    date: "",
    icon: "trending-up",
    completed: false,
  },
]

const defaultUser: User = {
  id: "1",
  username: "Guest",
  email: "guest@example.com",
  level: 1,
  rank: "F",
  strength: 1,
  speed: 1,
  health: 1,
  defence: 1,
  dungeonsCleared: 124,
  shadowSoldiers: 7,
  guildPosition: "Guild Master",
  xp: 0,
  totalXp: 0,
  registeredAt: new Date().toISOString(),
  lastLogin: new Date().toISOString(),
  country: "Japan",
  profilePicture: getRandomProfilePic(),
  achievements: JSON.parse(JSON.stringify(defaultAchievements)),
  workoutsCompleted: 0,
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const router = useRouter()

  // Load user from localStorage on initial render
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        console.error("Failed to parse stored user:", error)
        localStorage.removeItem("user")
      }
    }
  }, [])

  // Calculate XP needed for next level based on current level
  const calculateXpForLevel = (level: number): number => {
    // Return level * 10 XP for each level
    return level * 10
  }

  // Determine rank based on total XP
  const determineRank = (totalXp: number): string => {
    if (totalXp < 10) return "Unranked"
    if (totalXp < 100) return "F"
    if (totalXp < 200) return "E"
    if (totalXp < 300) return "D"
    if (totalXp < 400) return "C"
    if (totalXp < 500) return "A"
    if (totalXp < 900) return "S"
    return "S+"
  }

  // Record a login event
  const recordLogin = (userId: string, username: string, email: string) => {
    try {
      const loginHistory = JSON.parse(localStorage.getItem("loginHistory") || "[]")

      // Create a new login record
      const newLogin: LoginRecord = {
        userId,
        username,
        email,
        timestamp: new Date().toISOString(),
        device: navigator.userAgent || "Unknown device",
      }

      // Add to history and save
      loginHistory.push(newLogin)
      localStorage.setItem("loginHistory", JSON.stringify(loginHistory))

      // Update user's last login time
      return newLogin.timestamp
    } catch (error) {
      console.error("Failed to record login:", error)
      return new Date().toISOString()
    }
  }

  // Get login history
  const getLoginHistory = (): LoginRecord[] => {
    try {
      return JSON.parse(localStorage.getItem("loginHistory") || "[]")
    } catch (error) {
      console.error("Failed to get login history:", error)
      return []
    }
  }

  // Unlock achievement
  const unlockAchievement = (type: AchievementType, details?: any) => {
    if (!user) return

    const updatedAchievements = [...user.achievements]
    const now = new Date().toISOString()

    // Handle different achievement types
    switch (type) {
      case "join":
        const joinAchievement = updatedAchievements.find((a) => a.id === "join")
        if (joinAchievement && !joinAchievement.completed) {
          joinAchievement.completed = true
          joinAchievement.date = now
        }
        break

      case "first_workout":
        const workoutAchievement = updatedAchievements.find((a) => a.id === "first_workout")
        if (workoutAchievement && !workoutAchievement.completed) {
          workoutAchievement.completed = true
          workoutAchievement.date = now
        }
        break

      case "first_level_up":
        const levelUpAchievement = updatedAchievements.find((a) => a.id === "first_level_up")
        if (levelUpAchievement && !levelUpAchievement.completed) {
          levelUpAchievement.completed = true
          levelUpAchievement.date = now
        }
        break

      case "first_rank":
        const rankAchievement = updatedAchievements.find((a) => a.id === "first_rank")
        if (rankAchievement && !rankAchievement.completed) {
          rankAchievement.completed = true
          rankAchievement.date = now
        }
        break

      case "rank_up":
        if (details && details.rank) {
          const rankId = details.rank === "S+" ? "rank_s_plus" : `rank_${details.rank.toLowerCase()}`
          const rankUpAchievement = updatedAchievements.find((a) => a.id === rankId)
          if (rankUpAchievement && !rankUpAchievement.completed) {
            rankUpAchievement.completed = true
            rankUpAchievement.date = now
          }
        }
        break

      case "level_up":
        if (details && details.level) {
          if (details.level === 2) {
            // First level up
            const firstLevelUpAchievement = updatedAchievements.find((a) => a.id === "first_level_up")
            if (firstLevelUpAchievement && !firstLevelUpAchievement.completed) {
              firstLevelUpAchievement.completed = true
              firstLevelUpAchievement.date = now
            }
          }

          // Check for level milestones
          const levelMilestones = [5, 10, 20, 50, 100]
          for (const milestone of levelMilestones) {
            if (details.level >= milestone) {
              const levelAchievement = updatedAchievements.find((a) => a.id === `level_${milestone}`)
              if (levelAchievement && !levelAchievement.completed) {
                levelAchievement.completed = true
                levelAchievement.date = now
              }
            }
          }
        }
        break
    }

    // Update user with new achievements
    const updatedUser = { ...user, achievements: updatedAchievements }
    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))

    // Update in users array too
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u: any) => (u.id === user.id ? { ...u, achievements: updatedAchievements } : u))
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  // Record workout completion
  const recordWorkout = () => {
    if (!user) return

    // Increment the workout count
    const workoutsCompleted = (user.workoutsCompleted || 0) + 1
    const updatedUser = { ...user, workoutsCompleted }

    // Check if this is the first workout
    if (workoutsCompleted === 1) {
      unlockAchievement("first_workout")
    }

    // Update user in state and localStorage
    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))

    // Update in users array too
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u: any) => (u.id === user.id ? { ...u, workoutsCompleted } : u))
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    console.log(`Workout recorded. Total workouts: ${workoutsCompleted}`)
  }

  const recordWorkoutCompletion = (type: string, level: string) => {
    if (!user) return

    const completionsData = localStorage.getItem(`${user.id}_workoutCompletions`)
    let completions: Record<string, number> = {}

    if (completionsData) {
      completions = JSON.parse(completionsData)
    }

    const key = `${type}_${level}`
    completions[key] = (completions[key] || 0) + 1

    localStorage.setItem(`${user.id}_workoutCompletions`, JSON.stringify(completions))

    console.log(`Recorded completion for ${type} workout (${level}). Total: ${completions[key]}`)
  }

  const login = (email: string, password: string): boolean => {
    // In a real app, you would validate against a backend
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const foundUser = users.find((u: any) => u.email === email && u.password === password)

    if (foundUser) {
      // Record the login
      const lastLogin = recordLogin(foundUser.id, foundUser.username, foundUser.email)

      // Make sure we have all required fields with defaults if missing
      const userData: User = {
        id: foundUser.id,
        username: foundUser.username,
        email: foundUser.email,
        level: foundUser.level || 1,
        rank: foundUser.rank || "Unranked",
        strength: foundUser.strength || 1,
        speed: foundUser.speed || 1,
        health: foundUser.health || 1,
        defence: foundUser.defence || 1,
        dungeonsCleared: foundUser.dungeonsCleared || 0,
        shadowSoldiers: foundUser.shadowSoldiers || 0,
        guildPosition: foundUser.guildPosition || "Member",
        xp: foundUser.xp || 0,
        totalXp: foundUser.totalXp || 0,
        registeredAt: foundUser.registeredAt || new Date().toISOString(),
        lastLogin: lastLogin,
        country: foundUser.country || "Unknown",
        profilePicture: foundUser.profilePicture || getRandomProfilePic(),
        achievements: foundUser.achievements || JSON.parse(JSON.stringify(defaultAchievements)),
        workoutsCompleted: foundUser.workoutsCompleted || 0, // Ensure this is properly handled
      }

      // Update the user in the users array with the new login time
      const updatedUsers = users.map((u: any) => (u.id === foundUser.id ? { ...u, lastLogin } : u))
      localStorage.setItem("users", JSON.stringify(updatedUsers))

      setUser(userData)
      localStorage.setItem("user", JSON.stringify(userData))
      return true
    }

    // For demo purposes, allow login with default user
    if (email === "guest@example.com" && password === "password") {
      const lastLogin = recordLogin(defaultUser.id, defaultUser.username, defaultUser.email)
      const guestUser = {
        ...defaultUser,
        lastLogin,
      }

      // Unlock the join achievement for the guest user
      const updatedAchievements = [...guestUser.achievements]
      const joinAchievement = updatedAchievements.find((a) => a.id === "join")
      if (joinAchievement) {
        joinAchievement.completed = true
        joinAchievement.date = lastLogin
      }

      guestUser.achievements = updatedAchievements

      setUser(guestUser)
      localStorage.setItem("user", JSON.stringify(guestUser))
      return true
    }

    return false
  }

  const register = (username: string, email: string, password: string): boolean => {
    try {
      // In a real app, you would send this to a backend
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      // Check if username or email already exists
      const userExists = users.some((u: any) => u.username === username || u.email === email)

      if (userExists) {
        return false
      }

      const registrationTime = new Date().toISOString()

      // List of countries for random assignment
      const countries = [
        "Japan",
        "South Korea",
        "USA",
        "China",
        "Russia",
        "UK",
        "Germany",
        "France",
        "Brazil",
        "Australia",
      ]

      const country = "Select" // Default to "Select" instead of a random country
      const randomProfilePic = getRandomProfilePic()

      // Create achievements with join achievement already completed
      const achievements = JSON.parse(JSON.stringify(defaultAchievements))
      const joinAchievement = achievements.find((a: Achievement) => a.id === "join")
      if (joinAchievement) {
        joinAchievement.completed = true
        joinAchievement.date = registrationTime
      }

      const newUser: User & { password: string } = {
        id: Date.now().toString(),
        username,
        email,
        password, // In a real app, NEVER store passwords in plain text
        level: 1,
        rank: "Unranked",
        strength: 1,
        speed: 1,
        health: 1,
        defence: 1,
        dungeonsCleared: 0,
        shadowSoldiers: 0,
        guildPosition: "Member",
        xp: 0,
        totalXp: 0,
        registeredAt: registrationTime,
        lastLogin: registrationTime,
        country: country,
        profilePicture: randomProfilePic,
        achievements: achievements,
        workoutsCompleted: 0,
      }

      // Add the new user to the users array
      users.push(newUser)
      localStorage.setItem("users", JSON.stringify(users))

      // Record the registration as a login event too
      recordLogin(newUser.id, newUser.username, newUser.email)

      // Log the saved users for debugging
      console.log("Registered users:", users)

      // Auto login after registration
      const userData: User = { ...newUser }
      delete (userData as any).password
      setUser(userData)
      localStorage.setItem("user", JSON.stringify(userData))

      return true
    } catch (error) {
      console.error("Error during registration:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
    router.push("/login")
  }

  const isAuthenticated = (): boolean => {
    return user !== null
  }

  const updateStats = (stats: Partial<User>) => {
    if (!user) return

    const updatedUser = { ...user, ...stats }
    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))

    // Update in users array too
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u: any) => (u.id === user.id ? { ...u, ...stats } : u))
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  // Update user profile (country, profile picture, etc.)
  const updateUserProfile = (data: Partial<User>) => {
    if (!user) return

    const updatedUser = { ...user, ...data }
    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))

    // Update in users array too
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u: any) => (u.id === user.id ? { ...u, ...data } : u))
    localStorage.setItem("users", JSON.stringify(updatedUsers))
  }

  // Add a function to add XP and handle level ups
  const addXp = (amount: number) => {
    if (!user) return

    // Calculate new XP and level
    let newXp = user.xp + amount
    let newLevel = user.level
    const newTotalXp = user.totalXp + amount
    let leveledUp = false

    // Check if user leveled up
    const xpForNextLevel = calculateXpForLevel(newLevel)

    // Initialize stat increases
    let strengthIncrease = 0
    let speedIncrease = 0
    let healthIncrease = 0
    let defenceIncrease = 0

    if (newXp >= xpForNextLevel) {
      newXp -= xpForNextLevel
      newLevel++
      leveledUp = true

      // Increase all stats by 1 on level up
      strengthIncrease = 1
      speedIncrease = 1
      healthIncrease = 1
      defenceIncrease = 1

      // Unlock level up achievements
      unlockAchievement("level_up", { level: newLevel })
    }

    // Determine new rank based on total XP
    const newRank = determineRank(newTotalXp)

    // Check if rank changed
    if (newRank !== user.rank) {
      // Unlock rank achievements
      if (user.rank === "Unranked" && newRank !== "Unranked") {
        unlockAchievement("first_rank")
      }
      unlockAchievement("rank_up", { rank: newRank })
    }

    const updatedUser = {
      ...user,
      xp: newXp,
      level: newLevel,
      totalXp: newTotalXp,
      rank: newRank,
      // Increase stats if leveled up
      strength: user.strength + strengthIncrease,
      speed: user.speed + speedIncrease,
      health: user.health + healthIncrease,
      defence: user.defence + defenceIncrease,
    }

    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))

    // Update in users array too
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u: any) =>
      u.id === user.id
        ? {
            ...u,
            xp: newXp,
            level: newLevel,
            totalXp: newTotalXp,
            rank: newRank,
            strength: u.strength + strengthIncrease,
            speed: u.speed + speedIncrease,
            health: u.health + healthIncrease,
            defence: u.defence + defenceIncrease,
          }
        : u,
    )
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    return leveledUp
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        isAuthenticated,
        updateStats,
        addXp,
        getLoginHistory,
        updateUserProfile,
        unlockAchievement,
        recordWorkout,
        recordWorkoutCompletion,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
