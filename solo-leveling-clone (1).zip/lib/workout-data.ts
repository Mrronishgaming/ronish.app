// Workout data types
export type WorkoutType = "push" | "pull" | "abslegs"
export type DifficultyLevel = "beginner" | "intermediate" | "advanced"

export type Exercise = {
  name: string
  duration: string // Can be reps (e.g., "3") or time (e.g., "30s")
  rest?: string // Rest period after exercise
  sets?: number // Number of sets (if applicable)
}

export type WorkoutSection = {
  title: string
  exercises: Exercise[]
}

export type Workout = {
  title: string
  description: string
  sections: WorkoutSection[]
}

// Push Workouts
const pushWorkouts: Record<DifficultyLevel, Workout> = {
  beginner: {
    title: "Push - Beginner",
    description: "Chest, Shoulders, Triceps workout for beginners",
    sections: [
      {
        title: "Warm Up",
        exercises: [
          { name: "Jumping jacks", duration: "20" },
          { name: "Wrist Roll", duration: "20" },
          { name: "Elbow Circle", duration: "20" },
          { name: "Arm Circle", duration: "20" },
          { name: "Push up", duration: "10" },
        ],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Pseudo pushup", duration: "3", rest: "60s" },
          { name: "Pseudo pushup", duration: "3", rest: "60s" },
          { name: "Pseudo pushup", duration: "3", rest: "60s" },
          { name: "Dip", duration: "3", rest: "60s" },
          { name: "Dip", duration: "3", rest: "60s" },
          { name: "Dip", duration: "3", rest: "60s" },
          { name: "Pike Pushup", duration: "3", rest: "60s" },
          { name: "Pike Pushup", duration: "3", rest: "60s" },
          { name: "Pike Pushup", duration: "3", rest: "60s" },
          { name: "Push up", duration: "6", rest: "60s" },
          { name: "Push up", duration: "6", rest: "60s" },
          { name: "Push up", duration: "6" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Shoulder Extension", duration: "30s" },
          { name: "Wall Downdog", duration: "30s" },
          { name: "Twisted Downward Dog (each side)", duration: "30s" },
        ],
      },
    ],
  },
  intermediate: {
    title: "Push - Intermediate",
    description: "Chest, Shoulders, Triceps workout for intermediate level",
    sections: [
      {
        title: "Warm Up",
        exercises: [
          { name: "Jumping jacks", duration: "20" },
          { name: "Wrist Roll", duration: "20" },
          { name: "Elbow Circle", duration: "20" },
          { name: "Arm Circle", duration: "20" },
          { name: "Push up", duration: "10" },
        ],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Wall handstand pushup", duration: "3", rest: "60s" },
          { name: "Wall handstand pushup", duration: "3", rest: "60s" },
          { name: "Wall handstand pushup", duration: "3", rest: "60s" },
          { name: "Dip", duration: "10", rest: "60s" },
          { name: "Dip", duration: "10", rest: "60s" },
          { name: "Dip", duration: "10", rest: "60s" },
          { name: "Push up", duration: "10", rest: "60s" },
          { name: "Push up", duration: "10", rest: "60s" },
          { name: "Push up", duration: "10", rest: "60s" },
          { name: "Triceps Extension", duration: "8", rest: "60s" },
          { name: "Triceps Extension", duration: "8", rest: "60s" },
          { name: "Triceps Extension", duration: "8" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Shoulder Extension", duration: "30s" },
          { name: "Wall Downdog", duration: "30s" },
          { name: "Twisted Downward Dog (each side)", duration: "30s" },
        ],
      },
    ],
  },
  advanced: {
    title: "Push - Advanced",
    description: "Chest, Shoulders, Triceps workout for advanced level",
    sections: [
      {
        title: "Warm Up",
        exercises: [
          { name: "Jumping jacks", duration: "20" },
          { name: "Wrist Roll", duration: "20" },
          { name: "Elbow Circle", duration: "20" },
          { name: "Arm Circle", duration: "20" },
          { name: "Push up", duration: "10" },
        ],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Wall handstand pushup", duration: "8", rest: "60s" },
          { name: "Wall handstand pushup", duration: "8", rest: "60s" },
          { name: "Wall handstand pushup", duration: "8", rest: "60s" },
          { name: "Dip", duration: "15", rest: "60s" },
          { name: "Dip", duration: "15", rest: "60s" },
          { name: "Dip", duration: "15", rest: "60s" },
          { name: "Push up", duration: "15", rest: "60s" },
          { name: "Push up", duration: "15", rest: "60s" },
          { name: "Push up", duration: "15", rest: "60s" },
          { name: "Adv. Triceps Extension", duration: "8", rest: "60s" },
          { name: "Adv. Triceps Extension", duration: "8", rest: "60s" },
          { name: "Adv. Triceps Extension", duration: "8" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Shoulder Extension", duration: "30s" },
          { name: "Wall Downdog", duration: "30s" },
          { name: "Twisted Downward Dog (each side)", duration: "30s" },
        ],
      },
    ],
  },
}

// Pull Workouts
const pullWorkouts: Record<DifficultyLevel, Workout> = {
  beginner: {
    title: "Pull - Beginner",
    description: "Back, Biceps, Forearms workout for beginners",
    sections: [
      {
        title: "Warm Up",
        exercises: [
          { name: "Jumping jacks", duration: "20" },
          { name: "Wrist Roll", duration: "20" },
          { name: "Elbow Circle", duration: "20" },
          { name: "Arm Circle", duration: "20" },
          { name: "Active bar hang", duration: "10s" },
        ],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Pullup", duration: "3", rest: "60s" },
          { name: "Pullup", duration: "3", rest: "60s" },
          { name: "Pullup", duration: "3", rest: "60s" },
          { name: "Tuck Front lever Raise", duration: "3", rest: "60s" },
          { name: "Tuck Front lever Raise", duration: "3", rest: "60s" },
          { name: "Tuck Front lever Raise", duration: "3", rest: "60s" },
          { name: "Chin Up", duration: "3", rest: "60s" },
          { name: "Chin Up", duration: "3", rest: "60s" },
          { name: "Chin Up", duration: "3", rest: "60s" },
          { name: "Body Row", duration: "3", rest: "60s" },
          { name: "Body Row", duration: "3", rest: "60s" },
          { name: "Body Row", duration: "3" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Shoulder Extension", duration: "30s" },
          { name: "Wall Downdog", duration: "30s" },
          { name: "Twisted Downward Dog (each side)", duration: "30s" },
        ],
      },
    ],
  },
  intermediate: {
    title: "Pull - Intermediate",
    description: "Back, Biceps, Forearms workout for intermediate level",
    sections: [
      {
        title: "Warm Up",
        exercises: [
          { name: "Jumping jacks", duration: "20" },
          { name: "Wrist Roll", duration: "20" },
          { name: "Elbow Circle", duration: "20" },
          { name: "Arm Circle", duration: "20" },
          { name: "Active bar hang", duration: "10s" },
          { name: "Torso Twist", duration: "20" },
        ],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Pullup", duration: "5", rest: "60s" },
          { name: "Pullup", duration: "5", rest: "60s" },
          { name: "Pullup", duration: "5", rest: "60s" },
          { name: "Ice Cream Makers", duration: "5", rest: "60s" },
          { name: "Ice Cream Makers", duration: "5", rest: "60s" },
          { name: "Ice Cream Makers", duration: "5", rest: "60s" },
          { name: "Adv. Body Row", duration: "8", rest: "60s" },
          { name: "Adv. Body Row", duration: "8", rest: "60s" },
          { name: "Adv. Body Row", duration: "8", rest: "60s" },
          { name: "Bodyweight Curl", duration: "8", rest: "60s" },
          { name: "Bodyweight Curl", duration: "8", rest: "60s" },
          { name: "Bodyweight Curl", duration: "8" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Shoulder Extension", duration: "30s" },
          { name: "Wall Downdog", duration: "30s" },
          { name: "Twisted Downward Dog (each side)", duration: "30s" },
        ],
      },
    ],
  },
  advanced: {
    title: "Pull - Advanced",
    description: "Back, Biceps, Forearms workout for advanced level",
    sections: [
      {
        title: "Warm Up",
        exercises: [
          { name: "Jumping jacks", duration: "20" },
          { name: "Wrist Roll", duration: "20" },
          { name: "Elbow Circle", duration: "20" },
          { name: "Arm Circle", duration: "20" },
          { name: "Active bar hang", duration: "10s" },
          { name: "Torso Twist", duration: "20" },
        ],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Pullup", duration: "10", rest: "60s" },
          { name: "Pullup", duration: "10", rest: "60s" },
          { name: "Pullup", duration: "10", rest: "60s" },
          { name: "Adv. Tuck Front lever Raise", duration: "6", rest: "60s" },
          { name: "Adv. Tuck Front lever Raise", duration: "6", rest: "60s" },
          { name: "Adv. Tuck Front lever Raise", duration: "6", rest: "60s" },
          { name: "Adv. Body Row", duration: "10", rest: "60s" },
          { name: "Adv. Body Row", duration: "10", rest: "60s" },
          { name: "Adv. Body Row", duration: "10", rest: "60s" },
          { name: "Reverse Bodyweight Curl", duration: "8", rest: "60s" },
          { name: "Reverse Bodyweight Curl", duration: "8", rest: "60s" },
          { name: "Reverse Bodyweight Curl", duration: "8" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Shoulder Extension", duration: "30s" },
          { name: "Wall Downdog", duration: "30s" },
          { name: "Twisted Downward Dog (each side)", duration: "30s" },
        ],
      },
    ],
  },
}

// Abs Workouts
const absWorkouts: Record<DifficultyLevel, Workout> = {
  beginner: {
    title: "Abs - Beginner",
    description: "Core workout for beginners",
    sections: [
      {
        title: "Warm Up",
        exercises: [{ name: "Jumping jacks", duration: "30s" }],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Plank", duration: "30s", rest: "10s" },
          { name: "Knee Side Raise", duration: "10", rest: "10s" },
          { name: "Lying Tuck Hold", duration: "30s", rest: "10s" },
          { name: "Tuck Reverse Crunch", duration: "10", rest: "10s" },
          { name: "Cross Climber", duration: "20", rest: "10s" },
          { name: "Superman", duration: "10", rest: "10s" },
          { name: "Plank", duration: "30s", rest: "10s" },
          { name: "Knee Side Raise", duration: "10", rest: "10s" },
          { name: "Lying Tuck Hold", duration: "30s", rest: "10s" },
          { name: "Tuck Reverse Crunch", duration: "10", rest: "10s" },
          { name: "Cross Climber", duration: "20", rest: "10s" },
          { name: "Superman", duration: "10" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Cat/Cow", duration: "30s" },
          { name: "Cobra Pose", duration: "30s" },
        ],
      },
    ],
  },
  intermediate: {
    title: "Abs - Intermediate",
    description: "Core workout for intermediate level",
    sections: [
      {
        title: "Warm Up",
        exercises: [{ name: "Jumping jacks", duration: "30s" }],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Plank Walk", duration: "10", rest: "30s" },
          { name: "Side Plank Raise", duration: "10", rest: "30s" },
          { name: "Hollow Body Hold", duration: "30s", rest: "30s" },
          { name: "Reverse Crunch", duration: "10", rest: "30s" },
          { name: "Advanced Leg Raises", duration: "10", rest: "30s" },
          { name: "Cross Climber", duration: "15", rest: "30s" },
          { name: "Superman", duration: "20", rest: "30s" },
          { name: "Plank Walk", duration: "10", rest: "30s" },
          { name: "Side Plank Raise", duration: "10", rest: "30s" },
          { name: "Hollow Body Hold", duration: "30s", rest: "30s" },
          { name: "Reverse Crunch", duration: "10", rest: "30s" },
          { name: "Advanced Leg Raises", duration: "10", rest: "30s" },
          { name: "Cross Climber", duration: "15", rest: "30s" },
          { name: "Superman", duration: "20", rest: "30s" },
          { name: "Wall Sit", duration: "20s" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Cat/Cow", duration: "30s" },
          { name: "Cobra Pose", duration: "30s" },
        ],
      },
    ],
  },
  advanced: {
    title: "Abs - Advanced",
    description: "Core workout for advanced level",
    sections: [
      {
        title: "Warm Up",
        exercises: [{ name: "Jumping jacks", duration: "30s" }],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Adv. Plank Walk", duration: "10", rest: "30s" },
          { name: "Side Plank Raise", duration: "15", rest: "30s" },
          { name: "Hollow Body Rocks", duration: "10", rest: "30s" },
          { name: "Reverse Crunch", duration: "15", rest: "30s" },
          { name: "Advanced Leg Raises", duration: "15", rest: "30s" },
          { name: "Cross Climber", duration: "20", rest: "30s" },
          { name: "Superman", duration: "30", rest: "30s" },
          { name: "Adv. Plank Walk", duration: "10", rest: "30s" },
          { name: "Side Plank Raise", duration: "15", rest: "30s" },
          { name: "Hollow Body Rocks", duration: "10", rest: "30s" },
          { name: "Reverse Crunch", duration: "15", rest: "30s" },
          { name: "Advanced Leg Raises", duration: "15", rest: "30s" },
          { name: "Cross Climber", duration: "20", rest: "30s" },
          { name: "Superman", duration: "30" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Cat/Cow", duration: "30s" },
          { name: "Cobra Pose", duration: "30s" },
        ],
      },
    ],
  },
}

// Legs Workouts
const legsWorkouts: Record<DifficultyLevel, Workout> = {
  beginner: {
    title: "Legs - Beginner",
    description: "Legs workout for beginners",
    sections: [
      {
        title: "Warm Up",
        exercises: [{ name: "Jumping jacks", duration: "20s" }],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Lunge", duration: "10", rest: "30s" },
          { name: "Glute Bridge", duration: "10", rest: "30s" },
          { name: "Deep Squat", duration: "10", rest: "30s" },
          { name: "Wall Sit", duration: "30s", rest: "30s" },
          { name: "Calf Raise", duration: "10", rest: "30s" },
          { name: "Lunge", duration: "10", rest: "30s" },
          { name: "Glute Bridge", duration: "10", rest: "30s" },
          { name: "Deep Squat", duration: "10", rest: "30s" },
          { name: "Wall Sit", duration: "30s", rest: "30s" },
          { name: "Calf Raise", duration: "10", rest: "30s" },
          { name: "Lunge", duration: "10", rest: "30s" },
          { name: "Glute Bridge", duration: "10" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Seated Forward Bend", duration: "30s" },
          { name: "Butterfly", duration: "30s" },
          { name: "Frog Stretch", duration: "30s" },
          { name: "Middle Split", duration: "30s" },
          { name: "Pancake", duration: "30s" },
          { name: "Pigeon", duration: "30s" },
          { name: "Spiderman Stretch", duration: "30s" },
          { name: "Front Split", duration: "30s" },
          { name: "Standing Forward Bend", duration: "30s" },
        ],
      },
    ],
  },
  intermediate: {
    title: "Legs - Intermediate",
    description: "Legs workout for intermediate level",
    sections: [
      {
        title: "Warm Up",
        exercises: [{ name: "Jumping jacks", duration: "20s" }],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Jumping Squat", duration: "6", rest: "30s" },
          { name: "Jumping Lunge", duration: "6", rest: "30s" },
          { name: "Bulgarian Squat", duration: "5", rest: "30s" },
          { name: "One Leg Glute Bridge", duration: "10", rest: "30s" },
          { name: "Assisted Pistol Squat", duration: "3", rest: "30s" },
          { name: "Deep Squat", duration: "30", rest: "30s" },
          { name: "One Leg Calf Raise", duration: "5", rest: "30s" },
          { name: "Jumping Squat", duration: "6", rest: "30s" },
          { name: "Jumping Lunge", duration: "6", rest: "30s" },
          { name: "Bulgarian Squat", duration: "5", rest: "30s" },
          { name: "One Leg Glute Bridge", duration: "10", rest: "30s" },
          { name: "Assisted Pistol Squat", duration: "3", rest: "30s" },
          { name: "Deep Squat", duration: "30", rest: "30s" },
          { name: "One Leg Calf Raise", duration: "5" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Seated Forward Bend", duration: "30s" },
          { name: "Butterfly", duration: "30s" },
          { name: "Frog Stretch", duration: "30s" },
          { name: "Middle Split", duration: "30s" },
          { name: "Pancake", duration: "30s" },
          { name: "Pigeon", duration: "30s" },
          { name: "Spiderman Stretch", duration: "30s" },
          { name: "Front Split", duration: "30s" },
          { name: "Standing Forward Bend", duration: "30s" },
        ],
      },
    ],
  },
  advanced: {
    title: "Legs - Advanced",
    description: "Legs workout for advanced level",
    sections: [
      {
        title: "Warm Up",
        exercises: [{ name: "Jumping jacks", duration: "20s" }],
      },
      {
        title: "Workout",
        exercises: [
          { name: "Jumping Squat", duration: "6", rest: "30s" },
          { name: "Jumping Lunge", duration: "6", rest: "30s" },
          { name: "Bulgarian Squat", duration: "5", rest: "30s" },
          { name: "One Leg Glute Bridge", duration: "10", rest: "30s" },
          { name: "Assisted Pistol Squat", duration: "3", rest: "30s" },
          { name: "Deep Squat", duration: "30", rest: "30s" },
          { name: "One Leg Calf Raise", duration: "5", rest: "30s" },
          { name: "Jumping Squat", duration: "6", rest: "30s" },
          { name: "Jumping Lunge", duration: "6", rest: "30s" },
          { name: "Bulgarian Squat", duration: "5", rest: "30s" },
          { name: "One Leg Glute Bridge", duration: "10", rest: "30s" },
          { name: "Assisted Pistol Squat", duration: "3", rest: "30s" },
          { name: "Deep Squat", duration: "30", rest: "30s" },
          { name: "One Leg Calf Raise", duration: "5" },
        ],
      },
      {
        title: "Stretching",
        exercises: [
          { name: "Seated Forward Bend", duration: "30s" },
          { name: "Butterfly", duration: "30s" },
          { name: "Frog Stretch", duration: "30s" },
          { name: "Middle Split", duration: "30s" },
          { name: "Pancake", duration: "30s" },
          { name: "Pigeon", duration: "30s" },
          { name: "Spiderman Stretch", duration: "30s" },
          { name: "Front Split", duration: "30s" },
          { name: "Standing Forward Bend", duration: "30s" },
        ],
      },
    ],
  },
}

// Combined Abs/Legs Workout
export const workoutData: Record<WorkoutType, Record<DifficultyLevel, Workout>> = {
  push: pushWorkouts,
  pull: pullWorkouts,
  abslegs: {
    beginner: {
      title: "Abs/Legs - Beginner",
      description: "Core and Legs workout for beginners",
      sections: [...absWorkouts.beginner.sections, ...legsWorkouts.beginner.sections],
    },
    intermediate: {
      title: "Abs/Legs - Intermediate",
      description: "Core and Legs workout for intermediate level",
      sections: [...absWorkouts.intermediate.sections, ...legsWorkouts.intermediate.sections],
    },
    advanced: {
      title: "Abs/Legs - Advanced",
      description: "Core and Legs workout for advanced level",
      sections: [...absWorkouts.advanced.sections, ...legsWorkouts.advanced.sections],
    },
  },
}

// Helper functions
export function getWorkoutData(type: WorkoutType, level: DifficultyLevel): Workout {
  return workoutData[type][level]
}

export function getAvailableLevels(type: WorkoutType): DifficultyLevel[] {
  return Object.keys(workoutData[type]) as DifficultyLevel[]
}
